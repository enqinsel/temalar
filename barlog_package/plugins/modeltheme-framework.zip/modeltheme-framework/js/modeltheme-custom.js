/*
 Project name:       MODELTHEME
 Project author:     ModelTheme
 File name:          Custom JS
*/
(function ($) {
  'use strict';
  jQuery( document ).ready(function() {
    /*
    * ||||||||||||||||||||||||||||||||||||||||||||||||||||||||-> TESTIMONIALS01 SLIDER (Shortcode)
    */
    /*
    * ||||||||||||||||||||||||||||||||||||||||||||||||||||||||-> SYNCED SLIDER / MAIN HOME
    */
    // function bs_fix_vc_full_width_row(){
    //     var $fullrow = jQuery('[data-vc-full-width="true"]');
    //     jQuery.each($fullrow, function () {
    //       jQuery('#mt_posts_carousel_big_centered').owlCarousel({
    //           // center: true,
    //           stagePadding: 200,
    //           items:1,
    //           loop:true,
    //           margin:10,
    //           nav: true,
    //           navText: ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"]
    //           // responsive:{
    //           //     600:{
    //           //         items:4
    //           //     }
    //           // }
    //       });
    //     });
    // }
    // function bs_fix_vc_full_width_row_v2(){
    //     var $fullrow = jQuery('[data-vc-full-width="true"]');
    //     jQuery.each($fullrow, function () {
    //       jQuery('#mt_posts_carousel_big_v2').owlCarousel({
    //             loop:true,
    //             margin:5,
    //             nav: false,
    //             stagePadding: 5,
    //             responsive:{
    //                 0:{
    //                     items:1,
    //                     nav:false
    //                 },
    //                 600:{
    //                     items:2,
    //                     nav:false,
    //                 },
    //                 900:{
    //                     items:2,
    //                     nav:false
    //                 },
    //                 1300:{
    //                     items:4,
    //                     loop:false
    //                 },
    //                 1500:{
    //                     items:5,
    //                     loop:false
    //                 }
    //             }
    //       });
    //     });
    // }
    // function bs_fix_vc_full_width_row_v3(){
    //     var $fullrow = jQuery('[data-vc-full-width="true"]');
    //     if(jQuery('#mt_posts_carousel_big_v3').hasClass('with_spacing')){
    //         var spacing = 5;
    //     } else {
    //         var spacing = 0;
    //     }
    //     jQuery.each($fullrow, function () {
    //       jQuery('#mt_posts_carousel_big_v3').owlCarousel({
    //             loop:true,
    //             margin: spacing,
    //             nav: false,
    //             stagePadding: spacing,
    //             responsive:{
    //                 0:{
    //                     items:1,
    //                     nav:false
    //                 },
    //                 600:{
    //                     items:2,
    //                     nav:false,
    //                 },
    //                 900:{
    //                     items:2,
    //                     nav:false
    //                 },
    //                 1300:{
    //                     items:3,
    //                     loop:false
    //                 },
    //                 1500:{
    //                     items:3,
    //                     loop:false
    //                 }
    //             }
    //       });
    //     });
    // }
    // function bs_fix_vc_full_width_row_v4(){
    //     var $fullrow = jQuery('[data-vc-full-width="true"]');
    //     jQuery.each($fullrow, function () {
    //       jQuery('#mt_posts_travel').owlCarousel({
    //             loop:true,
    //             margin: 30,
    //             nav: false,
    //             stagePadding: 0,
    //             responsive:{
    //                 0:{
    //                     items:1,
    //                     nav:false
    //                 },
    //                 600:{
    //                     items:2,
    //                     nav:false,
    //                 },
    //                 900:{
    //                     items:2,
    //                     nav:false
    //                 },
    //                 1300:{
    //                     items:4,
    //                     loop:false
    //                 },
    //                 1500:{
    //                     items:4,
    //                     loop:false
    //                 }
    //             }
    //       });
    //     });
    // }
    // jQuery(document).on('vc-full-width-row', function () {
    //     bs_fix_vc_full_width_row();
    // });
    // jQuery(document).on('vc-full-width-row', function () {
    //     bs_fix_vc_full_width_row_v2();
    // });
    // jQuery(document).on('vc-full-width-row', function () {
    //     bs_fix_vc_full_width_row_v3();
    // });
    // jQuery(document).on('vc-full-width-row', function () {
    //     bs_fix_vc_full_width_row_v4();
    // });
    // var sync1 = jQuery("#mt_posts_carousel_big");
    // var sync2 = jQuery("#mt_posts_carousel_small");
    // var duration = 300;
    // var thumbs = 3;
    // // Sync nav
    // sync1.on('click', '.owl-next', function () {
    //     sync2.trigger('next.owl.carousel')
    // });
    // sync1.on('click', '.owl-prev', function () {
    //     sync2.trigger('prev.owl.carousel')
    // });
    // // Start Carousel
    // sync1.owlCarousel({
    //     dots: false,
    //     loop: true,
    //     items : 1,
    //     margin:0,
    //     nav : true,
    //     navText: ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"]
    // })
    // .on('dragged.owl.carousel', function (e) {
    //     if (e.relatedTarget.state.direction == 'left') {
    //         sync2.trigger('next.owl.carousel')
    //     } else {
    //         sync2.trigger('prev.owl.carousel')
    //     }
    // });
    // sync2.owlCarousel({
    //     dots: false,
    //     loop: true,
    //     items : thumbs,
    //     margin:0,
    //     nav : false,
    //     responsive:{
    //         0:{
    //             items:1,
    //             nav:false
    //         },
    //         600:{
    //             items:1,
    //             nav:true
    //         },
    //         1000:{
    //             items:3,
    //             nav:true,
    //         }
    //     }
    // })
    // .on('click', '.owl-item', function() {
    //     var i = $(this).index()-(thumbs+1);
    //     sync2.trigger('to.owl.carousel', [i, duration, true]);
    //     sync1.trigger('to.owl.carousel', [i, duration, true]);
    // });

    // jQuery(function(){
        
    //     var spacing = 0;
    //     if(!jQuery('#mt_posts_grid_v1').hasClass('no_spacing')) {
    //         spacing = 20;
    //     }
    //     var currentHeight = jQuery('#mt_posts_grid_v1 .col-article-0').outerHeight();
    //     var height = (currentHeight - spacing)/2;

    //     if (jQuery(window).width() >= 768) {
    //         jQuery( '#mt_posts_grid_v1 .col-article-1 .blog_post_image' ).css( "height", height );
    //         jQuery( '#mt_posts_grid_v1 .col-article-2 .blog_post_image' ).css( "height", height );
    //     }

    //     jQuery(window).resize(function() {
    //         if (jQuery(window).width() >= 768) {

    //             var spacing = 0;
    //             if(!jQuery('#mt_posts_grid_v1').hasClass('no_spacing')) {
    //                 spacing = 20;
    //             }

    //             var currentHeight = jQuery('#mt_posts_grid_v1 .col-article-0').outerHeight();
    //             var height = (currentHeight - spacing)/2;
    //             jQuery( '#mt_posts_grid_v1 .col-article-1 .blog_post_image' ).css( "height", height );
    //             jQuery( '#mt_posts_grid_v1 .col-article-2 .blog_post_image' ).css( "height", height );
    //         }
    //     });   

    // });

   /* jQuery( '.col-article-1' ).css( "height", "red" );

    console.log("set current height on load = " + currentHeight)*/

    // jQuery(".testimonials-container").owlCarousel({
    //     navigation      : false, // Show next and prev buttons
    //     pagination      : true,
    //     autoPlay        : false,
    //     slideSpeed      : 700,
    //     paginationSpeed : 700,
    //     itemsCustom : [
    //         [0,     1],
    //         [450,   1],
    //         [600,   2],
    //         [700,   2],
    //         [1000,  2],
    //         [1200,  2],
    //         [1400,  2],
    //         [1600,  2]
    //     ]
    // });
   //  jQuery(".mt-posts-container-1").owlCarousel({
   // navigation      : false, // Show next and prev buttons
   //    pagination      : true,
   //    autoPlay        : false,
   //    slideSpeed      : 700,
   //    paginationSpeed : 700,
   //    singleItem      : true
   //   });
   jQuery(".mt-posts-container-1-variant-1").owlCarousel({
        items:1,
        loop:true,
        margin:15,
        nav: true,
        autoPlay        : true,
        slideSpeed      : 700,
        navText: ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
        responsive:{
            0:{
                items:1,
                nav:false
            },
            600:{
                items:1,
                nav:true
            },
            1000:{
                items:1,
                nav:true,
            }
        }
    });
    jQuery(".mt-posts-container-1-variant-2").owlCarousel({
        items:1,
        loop:true,
        margin: 15,
        autoPlay        : true,
        slideSpeed      : 700,
        nav: true,
        navText: ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
        responsive:{
            0:{
                items:1,
                nav:false
            },
            600:{
                items:1,
                nav:true
            },
            1000:{
                items:1,
                nav:true,
            }
        }
    });
    // jQuery(".testimonials-container-2").owlCarousel({
    //     navigation      : false, // Show next and prev buttons
    //     pagination      : true,
    //     autoPlay        : false,
    //     slideSpeed      : 700,
    //     paginationSpeed : 700,
    //     itemsCustom : [
    //         [0,     1],
    //         [450,   1],
    //         [600,   2],
    //         [700,   2],
    //         [1000,  2],
    //         [1200,  2],
    //         [1400,  2],
    //         [1600,  2]
    //     ]
    // });
    // jQuery(".testimonials-container-3").owlCarousel({
    //     navigation      : false, // Show next and prev buttons
    //     pagination      : false,
    //     autoPlay        : false,
    //     slideSpeed      : 700,
    //     paginationSpeed : 700,
    //     itemsCustom : [
    //         [0,     1],
    //         [450,   1],
    //         [600,   2],
    //         [700,   2],
    //         [1000,  3],
    //         [1200,  3],
    //         [1400,  3],
    //         [1600,  3]
    //     ]
    // });
    // /*
    // * ||||||||||||||||||||||||||||||||||||||||||||||||||||||||-> TESTIMONIALS02 SLIDER (Shortcode)
    // */
    // jQuery(".testimonials02-container").owlCarousel({
    //   navigation      : false, // Show next and prev buttons
    //   pagination      : true,
    //   autoPlay        : false,
    //   slideSpeed      : 700,
    //   paginationSpeed : 700,
    //   singleItem      : true
    // });
    // var feed = new Instafeed({
    //   get: 'tagged',
    //   tagName: 'themebarlog',
    //   clientId: '02b47e1b98ce4f04adc271ffbd26611d',
    //   accessToken: '4087253986.54da896.b87b07b1088d4bf4a220eac9ca3e7ba5',
    //   template: '<div class="mt-ig-item-holder"><a href="{{link}}" class="mt-ig-single-post" target="_blank" id="{{id}}"><img src="{{image}}" /><div class="mt-ig-overlay"><i class="icon-social-instagram icons"></i></div></a></div>',
    //   limit: 8,
    //   resolution: 'low_resolution',
    // });
    // feed.run();
    // var sync1 = jQuery("#mt_posts_carousel_big");
    // var sync2 = jQuery("#mt_posts_carousel_small");
   
    // sync1.owlCarousel({
    //   singleItem : true,
    //   mouseDrag : false,
    //   slideSpeed : 1000,
    //   navigation: true,
    //   navigationText  : ["<i class='fa fa-chevron-left'></i>","<i class='fa fa-chevron-right'></i>"],
    //   pagination:false,
    //   afterAction : syncPosition,
    //   responsiveRefreshRate : 200,
    // });
   
    // sync2.owlCarousel({
    //   items : 3,
    //   itemsDesktop      : [1199,3],
    //   itemsDesktopSmall     : [979,3],
    //   itemsTablet       : [768,3],
    //   itemsMobile       : [479,3],
    //   pagination:false,
    //   responsiveRefreshRate : 100,
    //   afterInit : function(el){
    //     el.find(".owl-item").eq(0).addClass("synced");
    //   }
    // });
   
    // function syncPosition(el){
    //   var current = this.currentItem;
    //   $("#mt_posts_carousel_small")
    //     .find(".owl-item")
    //     .removeClass("synced")
    //     .eq(current)
    //     .addClass("synced")
    //   if($("#mt_posts_carousel_small").data("owlCarousel") !== undefined){
    //     center(current)
    //   }
    // }
   
    // $("#mt_posts_carousel_small").on("click", ".owl-item", function(e){
    //   e.preventDefault();
    //   var number = $(this).data("owlItem");
    //   sync1.trigger("owl.goTo",number);
    // });
   
    // function center(number){
    //   var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
    //   var num = number;
    //   var found = false;
    //   for(var i in sync2visible){
    //     if(num === sync2visible[i]){
    //       var found = true;
    //     }
    //   }
   
    //   if(found===false){
    //     if(num>sync2visible[sync2visible.length-1]){
    //       sync2.trigger("owl.goTo", num - sync2visible.length+2)
    //     }else{
    //       if(num - 1 === -1){
    //         num = 0;
    //       }
    //       sync2.trigger("owl.goTo", num);
    //     }
    //   } else if(num === sync2visible[sync2visible.length-1]){
    //     sync2.trigger("owl.goTo", sync2visible[1])
    //   } else if(num === sync2visible[0]){
    //     sync2.trigger("owl.goTo", num-1)
    //   }
      
    // }
    // Tabs
    // jQuery('.naccs .menu div').click(function(){
    //   var tab_id = jQuery(this).attr('data-tab');
    //   jQuery('.naccs .menu div').removeClass('active');
    //   jQuery('.naccs ul li').removeClass('active');
    //   jQuery('.naccs .gc--1-of-3').removeClass('active');
    //   jQuery('.naccs .gc--2-of-3').removeClass('active');
      
    //   jQuery(this).parent().parent().addClass('active');
    //   jQuery("#"+tab_id).parent().parent().addClass('active');
    //   jQuery(this).addClass('active');
    //   jQuery("#"+tab_id).addClass('active');
    // })
    var $grid = $('.grid-masonry').masonry({
        itemSelector: ".grid-item",
        columnWidth: 0,
        gutter: 40,
        numColumns: 3
    });
    $grid.imagesLoaded().progress( function() {
        $grid.masonry('layout');
    });
  });
} (jQuery) )
;
