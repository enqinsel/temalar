<?php
function modeltheme_shortcode_blogpost_carousel($params, $content) {
    extract( shortcode_atts(
        array(
            'number'                 => '',
            'visible_items_posts'    => '',
            'variant'                => '',
            'order'                  => 'ASC',
            'size'                   => '',
            'image'                  => '',
            'blog_background_color'  => '',
            'background_color'       => '',
            'text_color'             => ''
        ), $params ) );

    $html = '';
    $html .= '<div class="row">';
    $html .= '<div class="wow mt-posts-slider mt-posts-container-'.$visible_items_posts.'-'.$variant.' owl-carousel owl-theme">';

    $args_posts = array(
        'posts_per_page'   => $number,
        'orderby'          => 'date',
        'order'            => $order,
        'post_type'        => 'post',
        'post_status'      => 'publish'
    );

    $posts = get_posts($args_posts);

    foreach ($posts as $post) {
        $post_id = $post->ID;
        $post_title = get_the_title($post_id);
        $content_post   = get_post($post_id);
        $content        = $content_post->post_content;

        $categories = get_the_category($post_id);
        if (!empty($categories)) {
            $category_name = $categories[0]->name;
            $category_link = get_category_link($categories[0]->term_id);
        }

        $post_thumbnail_id = get_post_thumbnail_id($post_id);
        if ($post_thumbnail_id) {
            $thumbnail_url = wp_get_attachment_image_url($post_thumbnail_id, $size);
        } else {
            // Use a placeholder or fallback image URL
            $thumbnail_url = 'path/to/your/placeholder-image.jpg';  // Update this to your placeholder image path
        }

        if($variant === 'variant-1'){
            $html .= '<div class="mt-carousel-wrapper">
                        <div class="mt-blogpost-carousel pull-left" style="background-image: url('.$thumbnail_url.');">
                            <div class="mt-blogpost-carousel-content '.$size.' col-12" style="background-color: '.$blog_background_color.'">
                                <a class="blogpost-category-link" href="'. esc_url($category_link) .'"><h5 class="blog-post-category-name">'.$category_name.'</h5></a>
                                <div class="mt-blogpost-carousel-txt">
                                    <div class="line-container" style="position: relative">                            
                                       <h4><a class="mt-blogpost-carousel-title-v2" href="'.get_permalink($post_id).'" title="'. esc_attr($post_title) .'">'.esc_html($post_title).'</a></h4>
                                    </div>   
                                    <div class="mt-blogpost-carousel-info element-post-info post-info-v2">
                                         <span class="element-time-n-date time-n-date-v2">'.get_the_time('j M, Y', $post->ID).'</span>
                                             <span class="author"><img class="blog_custom-2-img" src="'.esc_url(plugin_dir_url(__DIR__). 'img/triangle.svg').'" alt="" style="width:10px; height:10px"/> By <a href="'.esc_url(get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename'))).'" class="mt-blog-v2-author">'.get_the_author($post->ID).'</a></span>
                                    </div>                    
                                </div>
                                <button class="barlog-more-link-btn" style="background-color: '.$background_color.'; color:'.$text_color.'">
                                     <a href="'.get_permalink($post_id).'" >'.esc_html("Read More").'</a> 
                                </button>    
                            </div>
                        </div>
                    </div>';
        } elseif ($variant === 'variant-2') {
            $html .= '<div class="mt-carousel-wrapper">
                <div class="mt-blogpost-carousel-v2 pull-left" style="background-color: '.$blog_background_color.'">    
                    <div class="mt-blogpost-carousel-content-v2">
                        <a class="blogpost-category-link" href="'. esc_url($category_link) .'"><h5 class="blog-post-category-name">'.$category_name.'</h5></a>
                        <div class="mt-blogpost-carousel-txt">
                            <div class="line-container" style="position: relative">   
                                 <h4><a class="mt-blogpost-carousel-title-v2 title-short" href="'.get_permalink($post_id).'" title="'. esc_attr($post->post_title) .'">'.$post_title.'</a></h4>                         
                            </div>                                       
                        </div>
                            <div class="mt-blogpost-carousel-v2-img">
                                 <a class="relative" href="'.get_permalink($post_id).'"><img alt="'.$post_title.'" src="'.$thumbnail_url.'"/></a>
                            </div>
                            <div class="mt-blogpost-carousel-info element-post-info post-info-v2">
                                 <span class="element-time-n-date time-n-date-v2">'.get_the_time('j M, Y', $post->ID).'</span>
                                 <span class="author"><img class="blog_custom-2-img" src="'.esc_url(plugin_dir_url(__DIR__). 'img/triangle.svg').'" alt="" style="width:10px; height:10px"/> By <a href="'.esc_url(get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename'))).'" class="mt-blog-v2-author">'.get_the_author($post->ID).'</a></span>
                            </div>
                            <div class="post-excerpt row mt-blog-v2-description">
                                <p>'.modeltheme_excerpt_limit($content, 21).'</p>
                            </div> 
                        <button class="barlog-more-link-btn" style="background-color: '.$background_color.'; color:'.$text_color.'">
                              <a href="'.get_permalink($post_id).'" >'.esc_html("Read More").'</a>                           
                        </button>    
                    </div>
                </div>
            </div>';
        }
    }

    $html .= '</div>';
    $html .= '</div>';
    return $html;
}
add_shortcode('blogpost_carousel', 'modeltheme_shortcode_blogpost_carousel');

if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

    require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';

    $post_category_tax = get_terms('category');
    $post_category = array();
    foreach ( $post_category_tax as $term ) {
        $post_category[$term->name] = $term->slug;
    }

    vc_map( array(
        "name" => esc_attr__("MT - Blog Posts Carousel", 'modeltheme'),
        "base" => "blogpost_carousel",
        "category" => esc_attr__('MT: ModelTheme', 'modeltheme'),
        "icon" => "smartowl_shortcode",
        "params" => array(
            array(
                "group" => "Options",
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__( "Number Of Posts", 'modeltheme' ),
                "param_name" => "number",
                "value" => "",
                "description" => esc_attr__( "Enter Number Of Posts", 'modeltheme' )
            ),
            array(
                "group" => "Options",
                "type" => "dropdown",
                "heading" => esc_attr__("Visible Posts per slide", 'modeltheme'),
                "param_name" => "visible_items_posts",
                "std" => '',
                "holder" => "div",
                "class" => "",
                "description" => "",
                "value" => array(
                    '1'   => '1',
                    '2'   => '2',
                    '3'   => '3',
                    '4'   => '4',
                    '5'   => '5'
                )
            ),
            array(
                "group" => "Options",
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__("Select Variant"),
                "param_name" => "variant",
                "std" => '',
                "description" => esc_attr__(""),
                "value" => array(
                    esc_attr__('V1')     => 'variant-1',
                    esc_attr__('V2')     => 'variant-2'
                )
            ),
            array(
                "group" => "Options",
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__("Select Order", 'modeltheme'),
                "param_name" => "order",
                "std" => 'DESC',
                "description" => esc_attr__("Select the order direction (ascending or descending).", 'modeltheme'),
                "value" => array(
                    esc_attr__('Ascending (ASC)')  => 'ASC',
                    esc_attr__('Descending (DESC)') => 'DESC'
                )
            ),
            array(
                "group" => "Options",
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__("Select Size"),
                "param_name" => "size",
                "std" => '',
                "description" => esc_attr__(""),
                "value" => array(
                    esc_attr__('Small')     => 'col-md-6',
                    esc_attr__('Medium')     => 'col-md-8',
                    esc_attr__('Large')      => 'col-md-12'
                ),
                "dependency" => array(
                    "element" => 'variant',
                    'value' => 'variant-1'
                )
            ),
            array(
                "group" => "Styling",
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_attr__( "Choose button text color", 'modeltheme' ),
                "param_name" => "text_color",
                "value" => '', //Default color
                "description" => esc_attr__( "Choose button text color", 'modeltheme' )
            ),
            array(
                "group" => "Styling",
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_attr__( "Choose Button background color", 'modeltheme' ),
                "param_name" => "background_color",
                "value" => '', //Default color
                "description" => esc_attr__( "Choose Button background color", 'modeltheme' )
            ),
            array(
                "group" => "Styling",
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_attr__( "Choose blog card background color", 'modeltheme' ),
                "param_name" => "blog_background_color",
                "value" => '', //Default color
                "description" => esc_attr__( "Choose blog card background color", 'modeltheme' )
            )
        )
    ));
}

?>