<?php 


/**

||-> Shortcode: BlogPost01

*/
function modeltheme_shortcode_blogpost01($params, $content) {
    extract( shortcode_atts( 
        array(
            'variant'               =>'',
            'orderby'               =>'',
            'order'                 =>'',
            'animation'             =>'',
            'category'              => '',
            'number'                =>'',
            'blog_post_day_color'   =>'',
            'columns'               =>'',
            'card_background_color' =>'',
            'background_color'      =>'',
            'text_color'            =>''
        ), $params ) );


    $html = '';
    $html .= '<div class="blog-posts simple-posts blog-posts-shortcode wow '.$animation.'">';
    $html .= '<div class="row">';
    $args_blogposts = array(
            'posts_per_page'   => $number,
            'orderby'          => $orderby,
            'order'            => $order,
            'post_type'        => 'post',
            'tax_query' => array(
                array(
                    'taxonomy' => 'category',
                    'field' => 'slug',
                    'terms' => $category
                )
            ),
            'post_status'      => 'publish' 
            ); 
    $blogposts = get_posts($args_blogposts);


    foreach ($blogposts as $blogpost) {


        #thumbnail
        $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $blogpost->ID ),'numismatico_news_shortcode_800x666' );
        
        $content_post   = get_post($blogpost->ID);
        $content        = $content_post->post_content;
        $content        = apply_filters('the_content', $content);
        $content        = str_replace(']]>', ']]&gt;', $content);


        $categories = get_the_category($blogpost->ID);
        if (!empty($categories)) {
            $category_name = $categories[0]->name;
        }


        if ($thumbnail_src) {
            $post_img = '<img class="blog_post_image" style="box-shadow: '.$card_background_color.' 4px 4px 0 0, #000 4px 4px 0 1px" src="'. esc_url($thumbnail_src[0]) . '" alt="'.esc_attr($blogpost->post_title).'" />';
            $post_col = 'col-md-12';
        }else{
            $post_col = 'col-md-12 no-featured-image';
            $post_img = '';
        }

          $comments_count = wp_count_comments($blogpost->ID);
          if($comments_count->approved >= 1) {
              $comments = 'Comments <a href="'.get_comments_link($blogpost->ID).'">'. $comments_count->approved.'</a>';
          } else {
              $comments = 'No comments';
          }

        if ( ! empty( $categories ) ) {
            $category_link = get_category_link( $categories[0]->term_id );
        }

          if($variant === 'variant-1') {
              $html.='<div class="'.esc_attr($columns).'">
                      <article class="single-post list-view">
                        <div class="blog_custom">


                          <!-- POST THUMBNAIL -->
                          <div class="col-md-12 post-thumbnail">
                              <a class="relative" href="'.get_permalink($blogpost->ID).'">'.$post_img.'</a>
                              <span class="time-n-date">'.get_the_time('j M',$blogpost->ID).'</span>
                          </div>

                          <!-- POST DETAILS -->
                          <div class="post-details '.$post_col.'">

                          <div class="title-n-excerpt">
                            <h3 class="post-name row">
                              <a href="'.get_permalink($blogpost->ID).'" title="'. esc_attr($blogpost->post_title) .'">'. $blogpost->post_title .'</a>
                            </h3>
                            <div class="post-excerpt row">
                                <p>'.modeltheme_excerpt_limit($content, 21).'</p>
                            </div>
                          </div>

                            <div class="text-element content-element">
                              <p class="author">Post by <a href="'.get_author_posts_url($blogpost->ID).'">'.get_the_author($blogpost->ID).'</a></p>
                              <p class="comments">'.$comments.'</p>
                            </div>

                          </div>
                        </div>
                      </article>
                    </div>';
          } else {
              $html.='<div class="'.esc_attr($columns).'">
                      <article class="single-post list-view">
                        <div class="blog_custom-2" style="background-color: '.$card_background_color.'">
                        <a class="blogpost-category-link" href="'. esc_url( $category_link ).'"><h5 class="blog-post-category-name">'.$category_name.'</h5></a>                                             
                        <h5>
                        <a class="mt-blogpost-title-v2" href="'.get_permalink($blogpost->ID).'" title="'. esc_attr($blogpost->post_title) .'">'. $blogpost->post_title .'</a>
                        </h5>
                         
                          <!-- POST THUMBNAIL -->
                          <div class="col-md-12 post-thumbnail">
                              <a class="relative" href="'.get_permalink($blogpost->ID).'">'.$post_img.'</a>                     
                          </div>

                          <!-- POST DETAILS -->
                          <div class="post-details '.$post_col.'">

                            <div class="text-element content-element">
                            <div class="element-post-info post-info-v2">
                                 <span class="element-time-n-date time-n-date-v2">'.get_the_time('j M',$blogpost->ID).'</span>
                                 <span class="author"><img class="blog_custo-2-img" src="'.esc_url(plugin_dir_url( __DIR__ ).'img/triangle.svg').'" alt="" style="width:10px; height:10px"/> By <a href="'.esc_url(get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) )).'" class="mt-blog-v2-author">'.get_the_author($blogpost->ID).'</a></span>
                            </div>
                                                           
                            <div class="post-excerpt row mt-blog-v2-description">
                                <p>'.modeltheme_excerpt_limit($content, 21).'</p>
                            </div>

                            <div class="barlog-read-more-holder row">
                                    <a href="'.get_permalink($blogpost->ID).'" class="barlog-more-link-btn" style="background-color: '.$background_color.'; color:'.$text_color.'">Read More </a>
                            </div>
                          </div>
                        </div>
                      </article>
                    </div>';
          }
      }





    $html .= '</div>';
    $html .= '</div>';
    return $html;
}
add_shortcode('blogpost01', 'modeltheme_shortcode_blogpost01');

/**

||-> Map Shortcode in Visual Composer with: vc_map();

*/
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

    require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';

	$post_category_tax = get_terms('category');
	$post_category = array();
	foreach ( $post_category_tax as $term ) {
		$post_category[$term->name] = $term->slug;
	}

    vc_map( array(
     "name" => esc_attr__("MT - Blog Posts Grid", 'modeltheme'),
     "base" => "blogpost01",
     "category" => esc_attr__('MT: ModelTheme', 'modeltheme'),
     "icon" => "smartowl_shortcode",
     "params" => array(
         array(
             "group" => "Options",
             "type" => "dropdown",
             "holder" => "div",
             "class" => "",
             "heading" => esc_attr__("Select Variant"),
             "param_name" => "variant",
             "std" => '',
             "description" => esc_attr__(""),
             "value" => array(
                 esc_attr__('V1')     => 'variant-1',
                 esc_attr__('V2')     => 'variant-2'
             )
         ),
         array(
             "group" => "Options",
             "type" => "dropdown",
             "holder" => "div",
             "class" => "",
             "heading" => esc_attr__("Order By"),
             "param_name" => "orderby",
             "std" => '',
             "description" => esc_attr__(""),
             "value" => array(
                 esc_attr__('Date')     => 'post_date',
                 esc_attr__('ID')     => 'ID',
                 esc_attr__('Title')     => 'title',
                 esc_attr__('Name')     => 'name'
             )
         ),
         array(
             "group" => "Options",
             "type" => "dropdown",
             "holder" => "div",
             "class" => "",
             "heading" => esc_attr__("Select Order"),
             "param_name" => "order",
             "std" => '',
             "description" => esc_attr__(""),
             "value" => array(
                 esc_attr__('Desc')     => 'DESC',
                 esc_attr__('Asc')     => 'ASC'
             )
         ),
        array(
          "group" => "Options",
          "type" => "textfield",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__( "Number of posts", 'modeltheme' ),
          "param_name" => "number",
          "value" => "",
          "description" => esc_attr__( "Enter number of blog post to show.", 'modeltheme' )
        ),
        array(
           "type" => "dropdown",
           "group" => "Options",
           "holder" => "div",
           "class" => "",
           "heading" => esc_attr__("Select Blog Category"),
           "param_name" => "category",
           "description" => esc_attr__("Please select blog category"),
           "std" => 'Default value',
           "value" => $post_category
        ),
        array(
           "group" => "Options",
           "type" => "dropdown",
           "holder" => "div",
           "class" => "",
           "heading" => esc_attr__("Columns"),
           "param_name" => "columns",
           "std" => '',
           "description" => esc_attr__(""),
           "value" => array(
            esc_attr__('1 column')       => 'vc_col-sm-12',
            esc_attr__('2 columns')     => 'vc_col-sm-6',
            esc_attr__('3 columns')     => 'vc_col-sm-4',
           )
        ),
        array(
          "group" => "Styling",
          "type" => "colorpicker",
          "class" => "",
          "heading" => esc_attr__( "Choose blog post day color", 'modeltheme' ),
          "param_name" => "blog_post_day_color",
          "value" => '', //Default color
          "description" => esc_attr__( "Choose blog post day color", 'modeltheme' )
        ),
         array(
             "group" => "Styling",
             "type" => "colorpicker",
             "class" => "",
             "heading" => esc_attr__( "Choose card background-color", 'modeltheme' ),
             "param_name" => "card_background_color",
             "value" => '', //Default color
             "description" => esc_attr__( "Choose card background-color", 'modeltheme' )
         ),
         array(
             "group" => "Styling",
             "type" => "colorpicker",
             "class" => "",
             "heading" => esc_attr__( "Choose button text color", 'modeltheme' ),
             "param_name" => "text_color",
             "value" => '', //Default color
             "description" => esc_attr__( "Choose button text color", 'modeltheme' )
         ),
         array(
             "group" => "Styling",
             "type" => "colorpicker",
             "class" => "",
             "heading" => esc_attr__( "Choose Button background color", 'modeltheme' ),
             "param_name" => "background_color",
             "value" => '', //Default color
             "description" => esc_attr__( "Choose Button background color", 'modeltheme' )
         ),
        array(
          "group" => "Animation",
          "type" => "dropdown",
          "heading" => esc_attr__("Animation", 'modeltheme'),
          "param_name" => "animation",
          "std" => 'fadeInLeft',
          "holder" => "div",
          "class" => "",
          "description" => "",
          "value" => $animations_list
        )
      )
  ));
}

?>