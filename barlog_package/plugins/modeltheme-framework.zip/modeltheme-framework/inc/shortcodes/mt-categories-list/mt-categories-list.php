<?php
/**
||-> Shortcode: Title and Subtitle
*/
function modeltheme_categories_list_shortcode($params, $content) {
    extract( shortcode_atts( 
        array(
            'title'                     => '',
            'subtitle'                  => '',
            'title_color'               => '',
            'title_colorpicker'         => '',
            'subtitle_color'            => '',
            'subtitle_colorpicker'      => '',
            'align_title'               => '',
            'animation'                 => ''
        ), $params ) ); 

    $html = '';

    $categories = get_categories('orderby=count&order=desc');


    $content = '';
    $count = 0;

    foreach($categories as $category) {

        $content .= '<div class="category-list-shortcode category-list-'.$count.'">';

            $args_blogposts = array(
                'post_type'        => 'post',
                'posts_per_page'   => 1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'category',
                        'field' => 'slug',
                        'terms' => $category
                    )
                ),
            ); 

            $args_blogposts_count = array(
                'post_type'        => 'post',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'category',
                        'field' => 'slug',
                        'terms' => $category
                    )
                ),
            ); 

            $blogposts = get_posts($args_blogposts);

            $blogposts_count = get_posts($args_blogposts_count);

            foreach ($blogposts as $blogpost) {
               if (has_post_thumbnail( $blogpost )){

                    $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $blogpost->ID ), 'barlog_categories_list');
                  
                    $content .= '<img class="category-list-img" alt="" src="'.$thumbnail_src[0].'"/>';

                }
            }
                
            $content .= '<a class="cat-name" href="' . get_category_link($category->term_id) . '">' . $category->name . '</a>';

            $content .= '<span class="count-posts">' . $category->count . esc_html( ' Posts') . '</span>';

            $content .= '<div class="category-list-overlay"></div>';

        $content .= '</div>';

        $count++;
    }

    return $content;
}
add_shortcode('categories_list', 'modeltheme_categories_list_shortcode');
/**
||-> Map Shortcode in Visual Composer with: vc_map();
*/
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {
    require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';
    vc_map( 
        array(
            "name" => esc_attr__("MT - Categories List", 'modeltheme'),
            "base" => "categories_list",
            "category" => esc_attr__('MT: ModelTheme', 'modeltheme'),
            "icon" => "smartowl_shortcode",
            "params" => array(
                array(
                    "group" => "Options",
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_attr__( "Section title", 'modeltheme' ),
                    "param_name" => "title",
                    "value" => "",
                    "description" => ""
                ),
                array(
                    "type" => "dropdown",
                    "heading" => esc_attr__("Animation", 'modeltheme'),
                    "param_name" => "animation",
                    "std" => '',
                    "holder" => "div",
                    "class" => "",
                    "description" => "",
                    "value" => $animations_list,
                    "group" => "Animation"
                )              
            )
        )
    );
}