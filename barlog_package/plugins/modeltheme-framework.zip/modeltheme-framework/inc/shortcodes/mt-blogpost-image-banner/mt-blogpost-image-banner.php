<?php


/**

||-> Shortcode: BlogPostBanner

 */
function modeltheme_shortcode_blogpost_image_banner($params, $content) {
    extract( shortcode_atts(
        array(
            'post_id'                =>'',
            'banner_height'          =>'',
        ), $params ) );

    $html = '';
    $html .= '<div class="blog-posts simple-posts blog-posts-shortcode wow">';
    $html .= '<div class="row">';

    $post_title = get_the_title($post_id);

    $content_post   = get_post($post_id);
    $content        = $content_post->post_content;

    $categories = get_the_category($post_id);
    if (!empty($categories)) {
        $category_name = $categories[0]->name;
    }

    $post_thumbnail_id = get_post_thumbnail_id( $post_id );

    if ( ! $post_thumbnail_id ) {
        return false;
    }

    $size = 'full';
    $thumbnail_url = wp_get_attachment_image_url( $post_thumbnail_id, $size );

    if ( ! empty( $categories ) ) {
        $category_link = get_category_link( $categories[0]->term_id );
    }

    $html = '';
    $html.='<div class="mt-blogpost-image-banner" style="background-image: url('.$thumbnail_url.'); height: '.$banner_height.'px;">
                <div class="mt-blogpost-image-category">
                   <a class="blogpost-category-link" href="'. esc_url( $category_link ).'"><h5 class="blog-post-category-name">'.$category_name.'</h5></a>
                </div>
                <div class="mt-blogpost-image-info">
                   <h4><a class="mt-blogpost-image-info" href="'.get_permalink($post_id).'" title="'. esc_attr($post_title) .'">'.$post_title.'</a></h4>
                   <h5 class="author">By <a href="'.esc_url(get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) )).'" class="mt-blogpost-image-banner-author">'.get_the_author($post_id).'</a></h5>
                </div>
            </div>';

    return $html;
}
add_shortcode('blogpost_image_banner', 'modeltheme_shortcode_blogpost_image_banner');

/**

||-> Map Shortcode in Visual Composer with: vc_map();

 */
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

    require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';

    $post_category_tax = get_terms('category');
    $post_category = array();
    foreach ( $post_category_tax as $term ) {
        $post_category[$term->name] = $term->slug;
    }

    vc_map( array(
        "name" => esc_attr__("MT - Blog Posts Image Banner", 'modeltheme'),
        "base" => "blogpost_image_banner",
        "category" => esc_attr__('MT: ModelTheme', 'modeltheme'),
        "icon" => "smartowl_shortcode",
        "params" => array(
            array(
                "group" => "Options",
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__( "Post ID", 'modeltheme' ),
                "param_name" => "post_id",
                "value" => "570",
                "description" => esc_attr__( "Enter ID of the post", 'modeltheme' )
            ),
            array(
                "group" => "Options",
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__( "Banner Height", 'modeltheme' ),
                "param_name" => "banner_height",
                "value" => "350",
                "description" => esc_attr__( "Enter container height", 'modeltheme' )
            ),
        )
    ));
}

?>