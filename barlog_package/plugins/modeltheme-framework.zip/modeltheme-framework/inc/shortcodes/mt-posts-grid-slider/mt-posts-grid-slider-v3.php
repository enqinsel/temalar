<?php 
/**
||-> Shortcode: Blog Post Slider
*/
function modeltheme_posts_grid_slider_v3($params, $content) {
    extract( shortcode_atts( 
        array(
            'posts_query' => '',
            'animation'           =>'',
            'spacing_grid' => '',
        ), $params ) );
      $output = '';
      if (is_array($posts_query)) {
          $posts_query['post_status'] = 'publish';
      }else {
          $posts_query .= '|post_status:publish';
      }
      if (function_exists('vc_build_loop_query')) {
          list($query_args, $loop) = vc_build_loop_query($posts_query);
          $loop = new WP_Query($query_args);
      }else {
          $query_args = array('posts_per_page' => 10, 'ignore_sticky_posts' => 1);
          // just display first 10 posts if the user came directly to this shortcode
          $loop = new WP_Query($query_args);
      }
      // Loop through the posts and do something with them.
      if ($loop->have_posts()) :
          $output .= '<div id="mt_posts_carousel_big_v3" class="owl-carousel '.$spacing_grid.' mt-posts-carousel-v2 mt-posts-carousel-big-'.uniqid().'">';
            while ($loop->have_posts()) : $loop->the_post();
                $output .= '<article id="post-big-' . get_the_ID() . '" class="' . join(' ', get_post_class('', get_the_ID())) . '">';
                  
                  $output .= '<div class="mt-post-image">';
                    $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ),'barlog_sliderv2' );
                    if(!empty($thumbnail_src)){
                      $output .= '<img class="blog_post_image" src="'. esc_url($thumbnail_src[0]) . '" alt="'.esc_attr(get_the_title()).'" />';
                    }
                    $output .= '<div class="overlay_image_v2"></div>';
                  $output .= '</div>';
                  
                  $output .= '<div class="mt_posts_carousel_v2-group">';
                    $output .= '<div class="mt_posts_carousel_v2-inner">';
                      if (get_the_tags()) {
                        $output .= '<div class="group-meta">'. get_the_term_list( get_the_ID(), 'post_tag', '', ' ' ).'</div>';
                      }
                      $output .= '<h3 class="mt-post-title">';
                        $output .= '<a href="' . get_permalink() . '" title="' . esc_attr(get_the_title()) . '" rel="bookmark">' . esc_attr(get_the_title()) . '</a>';
                      $output .= '</h3>';   
                      $output .= '<span class="post-author">';
                        $output .= '<a href="'.esc_url(get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) )).'">by '.get_the_author().'</a>';
                      $output .= '</span>';                  
                    $output .= '</div>';
                  $output .= '</div>';      
                
                $output .= '</article>';
            endwhile;
            wp_reset_postdata();
          $output .= '</div>';
      endif;

    return $output;
}
add_shortcode('mt_posts_grid_slider_v3', 'modeltheme_posts_grid_slider_v3');
/**
||-> Map Shortcode in Visual Composer with: vc_map();
*/
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {
    require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';
    vc_map( array(
     "name" => esc_attr__("MT - Blog Posts Grid Slider V3", 'modeltheme'),
     "base" => "mt_posts_grid_slider_v3",
     "category" => esc_attr__('MT: ModelTheme', 'modeltheme'),
     "icon" => "smartowl_shortcode",
     "params" => array(
        array(
            "group" => "Options",
            'type' => 'loop',
            'param_name' => 'posts_query',
            'heading' => __('Posts query', 'modeltheme'),
            'value' => 'size:10|order_by:date',
            'settings' => array(
                'size' => array(
                    'hidden' => false,
                    'value' => 10,
                ),
                'order_by' => array('value' => 'date'),
                'post_type' => array(
                    'hidden' => false,
                ),
            ),
            'description' => __('Create WordPress loop, to populate content from your site.', 'modeltheme'),
            'admin_label' => true
        ),
        array(
          "group" => "Options",
          "type" => "dropdown",
          "holder" => "div",
          "class" => "",
          "heading" => esc_attr__("Spacing Grid"),
          "param_name" => "spacing_grid",
          "std" => '',
          "value" => array(
            'With spacing'     => 'with_spacing',
            'No spacing'     => 'no_spacing',
          )
        ),
        array(
          "group" => "Animation",
          "type" => "dropdown",
          "heading" => esc_attr__("Animation", 'modeltheme'),
          "param_name" => "animation",
          "std" => 'fadeInLeft',
          "holder" => "div",
          "class" => "",
          "description" => "",
          "value" => $animations_list
        )
      )
  ));
}
?>