<?php 
/* ------------------------------------------------------------------
[Modeltheme - SHORTCODES]
[Table of contents]
    Recent Tweets
    Contact Form
    Recent Posts
    Featured Post with thumbnail
    Subscribe form
    Skill
    Pricing tables
    Jumbot
    Alert
    Progress bars
    Custom content
    Responsive video (YouTube)
    Heading With Border
    Testimonials
    List group
    Thumbnails custom content
    Section heading with title and subtitle
    Section heading with title
    Heading with bottom border
    Call to action
    Blog posts
    Social Media
    Quotes
    Banner
    Our Services
    Quotes Slider
    Courses
------------------------------------------------------------------ */
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
// include_once( 'mt-members/mt-members-slider.php' ); # Members 01
include_once( 'mt-services/mt_custom_service.php' ); # Services 03
include_once( 'mt-contact/mt-contact01.php' );
include_once( 'mt-blog-posts/mt-blogpost01.php' ); # Blog Post
include_once( 'mt-blog-posts/mt-blogpost02.php' ); # Blog Post Version 2
include_once ('mt-pattern-title/mt-pattern-title.php'); # Pattern Title
include_once( 'mt-title-subtitle/mt-title-subtitle.php' ); # Title Subtitle
include_once( 'mt-social-icons/mt-social-icons.php' ); # Social Icons
include_once( 'mt-social-icon/mt-social-icon.php' ); # Social Icons
include_once( 'mt-featured-post/mt-featured-post.php' ); # Featured Post
include_once( 'mt-skills/mt-skills.php' ); # Skills
include_once( 'mt-countdown/mt-countdown.php' ); # Countdown
include_once( 'mt-icon-list-item/mt-icon-list-item.php' ); # Mailchimp Subscribe Form
include_once( 'mt-typed-text/mt-typed-text.php' ); # Typed text
include_once( 'mt-video/mt-video.php' ); # Video
include_once( 'mt-mailchimp-subscribe-form/mt-mailchimp-subscribe-form.php' ); # Mailchimp Subscribe Form
include_once( 'mt-sharer/mt-sharer.php' ); # Featured Product
include_once( 'mt-coundown-version2/mt-coundown-version2.php' ); # CountDown Version 2
include_once( 'mt-tabs/mt-tabs.php' ); # Tabs
include_once( 'mt-posts-grid-slider/mt-posts-grid-slider.php' ); # Tabs
include_once( 'mt-posts-grid-slider/mt-posts-grid-slider-centered.php' ); # Tabs
include_once( 'mt-posts-grid-slider/mt-posts-grid-slider-v2.php' ); # Slider
include_once( 'mt-posts-grid-slider/mt-posts-grid-slider-v3.php' ); # Slider
include_once( 'mt-posts-grid-slider/mt-posts-grid-v1.php' ); # Slider
include_once( 'mt-posts-grid-slider/mt-posts-grid-v2.php' ); # Slider
include_once( 'mt-posts-grid-slider/mt-posts-grid-v3.php' ); # Slider
include_once( 'mt-posts-grid-slider/mt-posts-travel-slider.php' ); # Slider
include_once( 'mt-posts-grid-slider/mt-posts-travel-grid.php' ); # Slider
include_once( 'mt-map-pins/mt-map-pins.php' ); # Map Pins
include_once( 'mt-categories-list/mt-categories-list.php' ); # Map Pins
include_once( 'mt-blogpost-banner/mt-blogpost-banner.php' ); # Blog Posts Banner
include_once ('mt-blogpost-carousel/mt-blogpost-carousel.php'); # Blog Post Carousel
include_once ('mt-blogpost-image-banner/mt-blogpost-image-banner.php'); # Blog Post Image Banner
include_once ('mt-masonry-posts/mt-masonry-posts.php'); # MT Masonry Posts
// include_once( 'mt-instagram-feed/mt-instagram-feed.php' ); # Tabs
// BOOTSTRAP ELEMENTS
include_once( 'mt-bootstrap-alert/mt-bootstrap-alert.php' ); # Bootstrap Alerts
include_once( 'mt-bootstrap-panel/mt-bootstrap-panel.php' ); # Bootstrap Panel
include_once( 'mt-panel/mt-panel.php' ); # Panel 2
include_once( 'mt-bootstrap-thumbnails-custom-content/mt-bootstrap-thumbnails-custom-content.php' ); # Bootstrap Thumbnails Custom Content
include_once( 'mt-bootstrap-listgroup/mt-bootstrap-listgroup.php' ); # Bootstrap List Group
include_once( 'mt-bootstrap-button/mt-bootstrap-button.php' ); # Bootstrap Buttons
?>