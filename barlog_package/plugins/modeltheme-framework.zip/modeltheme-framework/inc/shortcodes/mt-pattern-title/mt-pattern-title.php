<?php


/**

||-> Shortcode: PatternTitle

 */
function modeltheme_shortcode_pattern_title($params, $content)
{
    extract(shortcode_atts(
        array(
            'variant'        => '',
            'alignment'      =>'',
            'text'           => '',
            'number'         => '',
        ), $params));


    $content = '';
    if ($variant === 'variant-1'){
        $content.='<div class="mt-pattern-title">
                   <div class="mt-pattern-container" style="justify-content: '.$alignment.'">
                        <img class="pattern-img" src="'.esc_url(plugin_dir_url( __DIR__ ).'img/sep-left.svg').'"/>                        
                        <h2 class="mt-pattern-text-v1" style="font-size: '.$number.'px; font-weight: 600;">'.$text.'</h2>
                        <img class="pattern-img" src="'.esc_url(plugin_dir_url( __DIR__ ).'img/sep-title.svg').'"/>                        
                    </div>  
               </div>';
    } else {
        $content.='<div class="mt-pattern-title">
                   <div class="mt-pattern-container" style="justify-content: '.$alignment.'">                                      
                         <h2 class="mt-pattern-text-v2" style="font-size: '.$number.'px; font-weight: 600;">'.$text.'</h2>
                              <img class="pattern-img" src="'.esc_url(plugin_dir_url( __DIR__ ).'img/sep-left.svg').'"/>                             
                    </div>  
               </div>';
    }

    return $content;
}
add_shortcode('mt-pattern-title', 'modeltheme_shortcode_pattern_title');

/**

||-> Map Shortcode in Visual Composer with: vc_map();

 */
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {
    require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';
    vc_map( array(
        "name" => esc_attr__("MT - Pattern Title", 'modeltheme'),
        "base" => "mt-pattern-title",
        "category" => esc_attr__('MT: ModelTheme', 'modeltheme'),
        "icon" => "smartowl_shortcode",
        "params" => array(
            array(
                "group" => "Options",
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__("Select Variant"),
                "param_name" => "variant",
                "std" => '',
                "description" => esc_attr__(""),
                "value" => array(
                    esc_attr__('Pattern Both Sides')     => 'variant-1',
                    esc_attr__('Pattern Right Side')     => 'variant-2'
                )
            ),
            array(
                "group" => "Options",
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__("Select Alignment"),
                "param_name" => "alignment",
                "std" => '',
                "description" => esc_attr__(""),
                "value" => array(
                    esc_attr__('Left')     => 'flex-start',
                    esc_attr__('Center')     => 'center',
                    esc_attr__('Right')     => 'flex-end'
                )
            ),
            array(
                "group" => "Options",
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__( "Title Name", 'modeltheme' ),
                "param_name" => "text",
                "value" => "",
                "description" => esc_attr__( "Enter the title name.", 'modeltheme' )
            ),
            array(
                "group" => "Options",
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__( "Font Size", 'modeltheme' ),
                "param_name" => "number",
                "value" => "",
                "description" => esc_attr__( "Enter the title name.", 'modeltheme' )
            )
        )
    ));
}

?>