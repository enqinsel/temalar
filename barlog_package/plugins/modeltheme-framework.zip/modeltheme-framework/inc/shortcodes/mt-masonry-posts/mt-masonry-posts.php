<?php


/**

||-> Shortcode: MTMasonryPosts

 */
function modeltheme_shortcode_mt_masonry_posts($params, $content = NULL)
{
    extract(shortcode_atts(
        array(), $params));

    $html = '';
    $html .= '<div class="wow mt-masonry-posts grid-masonry">'.do_shortcode($content).'</div>';

    return $html;
}
    add_shortcode('mt_masonry_posts', 'modeltheme_shortcode_mt_masonry_posts');

function modeltheme_shortcode_mt_masonry_posts_item($params, $content)
{
    extract(shortcode_atts(
        array(
            'id'                =>'',
            'variant'           =>'',
            'height'            =>'',
        ), $params));

    $args_posts = array(
        'orderby' => 'post_date',
        'order' => 'ASC',
        'post_type' => 'post',
        'post_status' => 'publish'
    );

    $posts = get_posts($args_posts);

    foreach ($posts as $post) {

        $post_id = $id;

        $post_title = get_the_title($post_id);
        $background_color = get_post_meta($post_id, 'card_bg', true);

        $content_post = get_post($post_id);
        $content = $content_post->post_content;

        $categories = get_the_category($post_id);
        if (!empty($categories)) {
            $category_name = $categories[0]->name;
        }

        $post_thumbnail_id = get_post_thumbnail_id($post_id);

        if (!$post_thumbnail_id) {
            return false;
        }

        $size = 'full';
        $thumbnail_url = wp_get_attachment_image_url($post_thumbnail_id, $size);

        if (!empty($categories)) {
            $category_link = get_category_link($categories[0]->term_id);
        }

        if($variant === 'variant-1') {
        $html = '';
        $html .= '<div class="mt-masonry-item grid-item">
                       <div class="mt-masonry-item-wrapper" style="padding: 30px; border: 2px solid #222; box-shadow: #222 4px 4px 0 0; background-color: '.$background_color.'; margin-bottom: 40px;">               
                            <img alt="'.$post_title.'" src="'.$thumbnail_url.'"/>    
                             <div class="mt-masonry-item-category">
                                <a class="mt-masonry-item-link" href="' . esc_url($category_link) . '"><h5 class="mt-masonry-item-category-name">' . $category_name . '</h5></a>
                             </div>
                             <div class="mt-masonry-item-info">
                               <h5 class="mt-masonry-item-title" style="font-size: 22px; line-height: 1.2;><a class="mt-masonry-item-info-link" href="' . get_permalink($post_id) . '" title="' . esc_attr($post_title) . '">' . $post_title . '</a></h5>
                              <h6 class="mt-masonry-item-author">By <a href="' . esc_url(get_author_posts_url(get_the_author_meta('ID'), get_the_author_meta('user_nicename'))) . '" class="mt-masonry-item-author">' . get_the_author($post_id) . '</a></h6>
                            </div>
                        </div>
                   </div>'; } else {
                       $html .= '<div class="mt-masonry-item grid-item">
                                       <div class="mt-masonry-item-wrapper v2 row" style="padding: 30px; border: 2px solid #222; box-shadow: #222 4px 4px 0 0; background-color: '.$background_color.'; margin-bottom: 40px;"> 
                                            <div class="mt-mansory-item-img-group col-md-6">
                                                    <img alt="'.$post_title.'" src="'.$thumbnail_url.'"/>   
                                            </div>                                     
                                            <div class="mt-mansory-item-v2-group col-md-6">
                                                 <div class="mt-masonry-item-category">
                                                    <a class="mt-masonry-item-link" href="' . esc_url($category_link) . '"><h5 class="mt-masonry-item-category-name">' . $category_name . '</h5></a>
                                                 </div>         
                                                 <div class="mt-masonry-item-info">
                                                      <h5 style="font-weight: 600; line-height: 1.2;"><a class="mt-masonry-item-info-link-v2" style="margin-bottom: 8px;" href="' . get_permalink($post_id) . '" title="' . esc_attr($blogpost->post_title) . '">' . $post_title . '</a></h5>
                                                </div>
                                                  <div class="mt-masonry-description">
                                                       <p>'.modeltheme_excerpt_limit($content, 23).'</p>
                                                  </div>
                                                    <button class="barlog-masonry-more-link-btn" style="background-color: '.$background_color.'; color:'.$text_color.'">
                                                          <a href="'.get_permalink($post_id).'" >'.esc_html("Read More").'</a>                           
                                                    </button> 
                                            </div>                      
                                        </div>
                                   </div>';
                                }
        return $html;
    }
}

add_shortcode('mt_masonry_posts_item', 'modeltheme_shortcode_mt_masonry_posts_item');

    /**
     *
     * ||-> Map Shortcode in Visual Composer with: vc_map();
     */

if (function_exists('vc_map')) {

    $params_parent = array();
    $params_shortcode = array();

    if ($params_shortcode) {
        foreach ($params_shortcode as $param) {
            $params_parent[] = $param;
        }
    }

//    $extras_vc_fields = modeltheme_addons_extras_vc_fields();
//    if ($extras_vc_fields) {
//        foreach ($extras_vc_fields as $extra_param) {
//            $params_parent[] = $extra_param;
//        }
//    }

    vc_map(
        array(
            "name" => esc_attr__("MT: Masonry Posts", 'modeltheme-addons-for-wpbakery'),
            "base" => "mt_masonry_posts",
            "as_parent" => array('only' => 'mt_masonry_posts_item'),
            "content_element" => true,
            "show_settings_on_create" => true,
            "category" => esc_attr__('MT: ModelTheme', 'modeltheme-addons-for-wpbakery'),
            "is_container" => true,
            "params" => $params_parent,
            "js_view" => 'VcColumnView'
        )
    );

    $params_child = array();
    $params_child_shortcode = array(
        array(
            "type"         => "textfield",
            "holder"       => "div",
            "class"        => "",
            "param_name"   => "id",
            "heading"      => esc_attr__("Post ID", "modeltheme-addons-for-wpbakery"),
            "description"  => esc_attr__("Enter the post ID:", "modeltheme-addons-for-wpbakery"),
        ),
        array(
            "group" => "Options",
            "type" => "dropdown",
            "holder" => "div",
            "class" => "",
            "heading" => esc_attr__("Select Variant"),
            "param_name" => "variant",
            "std" => '',
            "description" => esc_attr__(""),
            "value" => array(
                esc_attr__('V1')     => 'variant-1',
                esc_attr__('V2')     => 'variant-2'
            )
        ),
        array(
            "type"         => "textfield",
            "holder"       => "div",
            "class"        => "",
            "param_name"   => "height",
            "value"        => "450",
            "heading"      => esc_attr__("Height", "modeltheme-addons-for-wpbakery"),
            "description"  => esc_attr__("Enter the height of container:", "modeltheme-addons-for-wpbakery"),
        ),
    );

    if ($params_child_shortcode) {
        foreach ($params_child_shortcode as $param_child) {
            $params_child[] = $param_child;
        }
    }

    //    if ($extras_vc_fields) {
    //        foreach ($extras_vc_fields as $extra_param) {
    //            $params_child[] = $extra_param;
    //        }
    //    }


    vc_map(
        array(
            "name" => esc_attr__("MT: Masonry Posts Item", "modeltheme-addons-for-wpbakery"),
            "base" => "mt_masonry_posts_item",
            "content_element" => true,
            "as_child" => array('only' => 'mt_masonry_posts'),
            "params" => $params_child
        )
    );
    //Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
    if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
        class WPBakeryShortCode_mt_masonry_posts extends WPBakeryShortCodesContainer {
        }
    }
    if ( class_exists( 'WPBakeryShortCode' ) ) {
        class WPBakeryShortCode_mt_masonry_posts_item extends WPBakeryShortCode {
        }
    }
    }
?>