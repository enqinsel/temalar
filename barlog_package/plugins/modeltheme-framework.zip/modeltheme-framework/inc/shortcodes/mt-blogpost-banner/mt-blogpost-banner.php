<?php


/**

||-> Shortcode: BlogPostBanner

 */
function modeltheme_shortcode_blogpost_banner($params, $content) {
    extract( shortcode_atts(
        array(
            'variant'                =>'',
            'post_id'                =>'',
            'blog_background_color'  =>'',
            'background_color'       =>'',
            'text_color'             =>''
        ), $params ) );

    $html = '';
    $html .= '<div class="blog-posts simple-posts blog-posts-shortcode wow">';
    $html .= '<div class="row">';

    $post_title = get_the_title($post_id);

    $content_post   = get_post($post_id);
    $content        = $content_post->post_content;
    $author_id      =  $content_post->post_author;

    $categories = get_the_category($post_id);
    if (!empty($categories)) {
        $category_name = $categories[0]->name;
    }

    $post_thumbnail_id = get_post_thumbnail_id( $post_id );

    if ( ! $post_thumbnail_id ) {
        return false;
    }
    $size = 'full';
    $thumbnail_url = wp_get_attachment_image_url( $post_thumbnail_id, $size);

    if ( ! empty( $categories ) ) {
        $category_link = get_category_link( $categories[0]->term_id );
    }

    $author_name = get_the_author_meta('display_name', $post_id);

    $html = '';
    if($variant === 'variant-1') {
        $html.='<div class="mt-blogpost-banner v1" style="background-color: '.$blog_background_color.'">
                <div class="col-md-8 col-sm-12 col-12 post-thumbnail">
                    <a class="relative" href="'.get_permalink($post_id).'"><img alt="'.$post_title.'" src="'.$thumbnail_url.'"/></a>
                </div>
                <div class="mt-blogpost-banner-content v1 col-md-4 col-sm-12 col-12">
                    <div class="mt-blogpost-banner-group">
                        <a class="blogpost-category-link" href="'. esc_url( $category_link ).'"><h5 class="blog-post-category-name">'.$category_name.'</h5></a>
                        <div class="mt-blogpost-banner-txt">
                            <div class="line-container" style="position: relative">
                                <h5><a class="mt-blogpost-banner-title-v1" href="'.get_permalink($post_id).'" title="'. esc_attr($post_title) .'">'.$post_title.'</a></h5>
                            </div>   
                            <div class="mt-blogpost-banner-info element-post-info post-info-v2">
                                 <span class="element-time-n-date time-n-date-v2">'.get_the_time('j M',$post_id).'</span>
                                 <span class="author"><img class="blog_custo-2-img" src="'.esc_url(plugin_dir_url( __DIR__ ).'img/triangle.svg').'" alt="" style="width:10px; height:10px"/> By <a href="'.esc_url(get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) )).'" class="mt-blog-v2-author mt-blogpost-banner-author">'.get_the_author($post_id).'</a></span>
                            </div>                    
                        </div>
                    </div>
                    <a href="'.get_permalink($post_id).'" class="barlog-more-link-btn" style="background-color: '.$background_color.'; color:'.$text_color.'">Read More </a>           
                </div>
            </div>';
    } else {
        $html.='<div class="mt-blogpost-banner v2" style="background-color: '.$blog_background_color.'">
                <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12 col-12 post-thumbnail">
                    <a class="relative" href="'.get_permalink($post_id).'"><img alt="'.$post_title.'" src="'.$thumbnail_url.'"/></a>
                </div>
                <div class="mt-blogpost-banner-content v2 col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
                    <div class="mt-blogpost-banner-group">
                        <a class="blogpost-category-link" href="'. esc_url( $category_link ).'"><h5 class="blog-post-category-name">'.$category_name.'</h5></a>
                        <div class="mt-blogpost-banner-txt">
                            <div class="line-container" style="position: relative">                 
                                <h6><a class="mt-blogpost-banner-title-v2" href="'.get_permalink($post_id).'" title="'. esc_attr($post_title) .'">'.$post_title.'</a></h6>
                            </div>  
                            <div class="mt-blogpost-banner-info element-post-info post-info-v2">
                                 <span class="element-time-n-date time-n-date-v2">'.get_the_time('j M',$post_id ).'</span>
                                 <span class="author"><img class="blog_custo-2-img" src="'.esc_url(plugin_dir_url( __DIR__ ).'img/triangle.svg').'" alt="" style="width:10px; height:10px"/> By <a href="'.esc_url(get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) )).'" class="mt-blog-v2-author mt-blogpost-banner-author">'.get_the_author($post_id).'</a></span>
                            </div>                        
                        </div>
                    </div>
                </div>
            </div>';
    }


    return $html;
}
add_shortcode('blogpost_banner', 'modeltheme_shortcode_blogpost_banner');

/**

||-> Map Shortcode in Visual Composer with: vc_map();

 */
if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

    require_once __DIR__ . '/../vc-shortcodes.inc.arrays.php';

    $post_category_tax = get_terms('category');
    $post_category = array();
    foreach ( $post_category_tax as $term ) {
        $post_category[$term->name] = $term->slug;
    }

    vc_map( array(
        "name" => esc_attr__("MT - Blog Posts Banner", 'modeltheme'),
        "base" => "blogpost_banner",
        "category" => esc_attr__('MT: ModelTheme', 'modeltheme'),
        "icon" => "smartowl_shortcode",
        "params" => array(
            array(
                "group" => "Options",
                "type" => "dropdown",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__("Select Variant"),
                "param_name" => "variant",
                "std" => '',
                "description" => esc_attr__(""),
                "value" => array(
                    esc_attr__('V1')     => 'variant-1',
                    esc_attr__('V2')     => 'variant-2'
                )
            ),
            array(
                "group" => "Options",
                "type" => "textfield",
                "holder" => "div",
                "class" => "",
                "heading" => esc_attr__( "Post ID", 'modeltheme' ),
                "param_name" => "post_id",
                "value" => "",
                "description" => esc_attr__( "Enter ID of the post", 'modeltheme' )
            ),
            array(
                "group" => "Styling",
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_attr__( "Choose button text color", 'modeltheme' ),
                "param_name" => "text_color",
                "value" => '', //Default color
                "description" => esc_attr__( "Choose button text color", 'modeltheme' )
            ),
            array(
                "group" => "Styling",
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_attr__( "Choose Button background color", 'modeltheme' ),
                "param_name" => "background_color",
                "value" => '', //Default color
                "description" => esc_attr__( "Choose Button background color", 'modeltheme' )
            ),
            array(
                "group" => "Styling",
                "type" => "colorpicker",
                "class" => "",
                "heading" => esc_attr__( "Choose blog card background color", 'modeltheme' ),
                "param_name" => "blog_background_color",
                "value" => '', //Default color
                "description" => esc_attr__( "Choose blog card background color", 'modeltheme' )
            )
        )
    ));
}

?>