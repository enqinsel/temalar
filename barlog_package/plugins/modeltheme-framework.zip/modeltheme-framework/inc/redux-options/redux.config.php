<?php
function extend_redux_tabs($sections) {
	$sections[] = array(
		'title' => esc_html__('MT AdPlaces', 'modeltheme') ,
		'id' => 'mt_adplaces',
		'icon' => 'el el-cogs'
	);
	$sections[] = array(
        'title'      => esc_html__( 'Header Ad place Banner', 'barlog' ),
        'id'         => 'mt_header_top',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'mt_header_ad_banner_status',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Header Ad place Banner Status', 'barlog' ),
                'subtitle' => esc_html__( 'Enable/Disable Ad place Banner', 'barlog' ),
                'desc'     => esc_html__( 'This Option Will Enable/Disable Ad place Banner', 'barlog' ),
                'options'  => array(
                    'on_adsense' => 'Enable AdSense',
                    'on'         => 'Enable Banner Ad',
                    'off'        => 'Disable Ad'
                ),
                'default'  => 'off'
            ),
            array(         
                'id'       => 'mt_header_ad_place_banner',
                'type'     => 'media',
                'title'    => esc_html__('Ad place Banner - background', 'barlog'),
                'default' => array('url' => esc_url(get_template_directory_uri().'/images/adplace-header.jpg')),
                'required' => array( 'mt_header_ad_banner_status', '=', 'on' )
            ),
            array(
                'id' => 'mt_header_ad_place_banner_link',
                'type' => 'text',
                'title' => esc_html__('Ad place Banner - link', 'barlog'),
                'subtitle' => esc_html__('Type your Ad place Banner url.', 'barlog'),
                'default' => 'https://',
                'required' => array( 'mt_header_ad_banner_status', '=', 'on' )
            ),
            array(
                'id' => 'mt_header_single_adsense_code',
                'type' => 'textarea',
                'title' => esc_html__('AdSense code', 'modeltheme'),
                'subtitle' => esc_html__('Paste your AdSense Code into the textarea.', 'modeltheme'),
                'desc' => esc_html__('The height of this ad will be automatically set from your AdSense account', 'modeltheme'),
                'required' => array( 'mt_header_ad_banner_status', '=', 'on_adsense' ),
                'default' => ''
            ),
        ),
    );
    $sections[] = array(
        'title' => esc_html__('AdPlace Blog Post', 'modeltheme') ,
        'id' => 'mt_adplaces_blog_post',
        'subsection' => true,
        'fields' => array(
            array(
                'id'       => 'mt_adplace_blog_post',
                'type'     => 'button_set',
                'title'    => esc_html__( 'AdPlace - Blog Post', 'modeltheme' ),
                'subtitle' => esc_html__( 'Select your "AdPlace content blog post"', 'modeltheme' ),
                //Must provide key => value pairs for radio options
                'options'  => array(
                    'on_adsense' => 'Enable AdSense',
                    'on'         => 'Enable Banner Ad',
                    'off'        => 'Disable Ad'
                ),
                'default'  => 'off'
            ),
            array(
                'id' => 'mt_adplace_blog_post_link',
                'type' => 'text',
                'title' => esc_html__('AdPlace URL', 'mtlistings'),
                'subtitle' => esc_html__('Type your AdPlace blog post URL.', 'mtlistings'),
                'required' => array( 'mt_adplace_blog_post', '=', 'on' ),
                'desc' => esc_html__('For example: "https://modeltheme.com"', 'mtlistings'),
                'default' => 'https://'
            ),
            array(
                'id' => 'mt_adplace_blog_post_img',
                'type' => 'media',
                'url' => true,
                'title' => esc_html__('Choose image for AdPlace Blog Post', 'modeltheme'),
                'subtitle' => esc_html__('Use the upload button to import media.', 'modeltheme'),
                'compiler' => 'true',
                'default' => array('url' => esc_url(get_template_directory_uri().'/images/adplace-header.jpg')),
                'required' => array( 'mt_adplace_blog_post', '=', 'on' )
            ),
            array(
                'id' => 'mt_adplace_blog_post_adsense_code',
                'type' => 'textarea',
                'title' => esc_html__('AdSense code', 'mtlistings'),
                'subtitle' => esc_html__('Paste your AdSense Code into the textarea.', 'mtlistings'),
                'desc' => esc_html__('The height of this ad will be automatically set from your AdSense account', 'mtlistings'),
                'required' => array( 'mt_adplace_blog_post', '=', 'on_adsense' ),
                'default' => ''
            ),
        ),
    );
	return $sections;
}
// In this example OPT_NAME is the returned opt_name.
add_filter("redux/options/redux_demo/sections", 'extend_redux_tabs');
?>