<a class="barlog-back-to-top barlog-is-visible barlog-fade-out" href="<?php echo esc_url('#0'); ?>">
    <i class="fas fa-angle-up"></i>
</a>