<div class="clearfix"></div>
<div class="barlog-read-more-holder">
    <a href="<?php echo esc_url(get_the_permalink()); ?>" class="barlog-more-link">
        <?php echo esc_html__( 'Read More', 'barlog' ); ?>
    </a>
</div>