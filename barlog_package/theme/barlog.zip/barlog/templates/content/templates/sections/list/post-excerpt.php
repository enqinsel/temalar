<div class="barlog-post-excerpt">
    <?php
    /* translators: %s: Name of current post */
    the_excerpt(); ?>
</div>