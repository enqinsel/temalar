<?php 
$class = "col-md-8 col-md-offset-2";
$sidebar = "sidebar-1";
if (!is_active_sidebar( $sidebar )) {
    $class = "col-md-12";
}
if ( Barlog()->get_setting('barlog_blog_archive_layout') == 'no-sidebar' ) {
    $class = "col-md-12 col-md-offset-2";
} else {
    $class = "col-md-8 col-md-offset-2";
}
?>
<div class="high-padding">
    <!-- Blog content -->
    <div class="container blog-posts">
        <div class="row">
			<?php do_action('barlog_before_blog_content'); ?>
			<div class="<?php echo esc_attr($class); ?> main-content">
				<?php
				// Include blog template
				echo get_template_part('templates/content/templates/sections/loop'); ?>
			</div>
			<?php #sidebar ?>
			<?php do_action('barlog_after_blog_pagination'); ?>
		</div>
	</div>
</div>