<?php
$class = "col-md-8 col-md-offset-2";
$sidebar = "sidebar-1";
if (!is_active_sidebar( $sidebar )) {
    $class = "col-md-12";
}

$post_id = get_the_ID();
$background_color = get_post_meta($post_id, 'card_bg', true);

if ( Barlog()->get_setting('barlog_blog_single_layout') == 'no-sidebar' ) {
	$class = "col-md-12 col-md-offset-2";
} else {
	$class = "col-md-8 col-md-offset-2";
}

?>

<div id="primary" class="content-area">
	<div class="site-main">
		<?php while ( have_posts() ) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class('post high-padding '. get_post_field( 'post_name', get_post() )); ?>>
			    <div class="container">
			       <div class="row">
			            <?php 
			            // Left Sidebar
			            do_action('barlog_before_single_post_content'); ?>
			            <div class="<?php echo esc_attr($class); ?> main-content">
							<div class="barlog-article-wrapper" style="padding: 30px; border: 2px solid #222; box-shadow: #222 4px 4px 0 0; background-color: <?php echo $background_color;?>;">
								<div class="article-header">
									<?php
									// Include Post Image
									get_template_part('templates/content/templates/sections/list/post-image' );?>
									<div class="clearfix"></div>
									<div class="barlog-post-metas">
										<div class="barlog-article-details">
											<h1><?php echo get_the_title(); ?></h1>
											<?php
											//Hook: Before post metas
											do_action('barlog_before_single_post_metas');

											// Include Post Author
											get_template_part('templates/content/templates/sections/list/post-author' );
											// Include Post Category
											get_template_part('templates/content/templates/sections/list/post-category' );
											// Include Post Date
											get_template_part('templates/content/templates/sections/list/post-date' );

											//Hook: After post metas
											do_action('barlog_after_single_post_metas');?>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>

								<div class="article-content">
									<?php the_content(); ?>
									<div class="clearfix"></div>
									<?php
									// Include Post Links Pages
									get_template_part('templates/content/templates/sections/list/post-link-pages' ); ?>
								</div>

								<?php
								// Include Post Tags
								get_template_part('templates/content/templates/sections/list/post-tags' ); ?>

								<div class="clearfix"></div>
								<?php
								// Include Post Comment Form
								get_template_part('templates/content/templates/sections/list/post-comment-form' ); ?>
							</div>
						</div>

			            
			            <?php 
			            // Right Sidebar
			            do_action('barlog_after_post_content'); ?>
			        </div>
			    </div>
			</article>
		<?php endwhile; ?>
	</div>
</div>