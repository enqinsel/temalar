<?php
/**
 * Get comments template
 *
 * @package barlog
 */

get_template_part('templates/comments/templates/comments');