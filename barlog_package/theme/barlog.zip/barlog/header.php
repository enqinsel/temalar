<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Barlog
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=10.0, user-scalable=yes">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php
if ( function_exists( 'wp_body_open' ) ) {
    wp_body_open();
}
?>
<div class="curzr" hidden></div>
<div id="page">
	<a class="skip-link screen-reader-text" href="#barlog-site-content"><?php esc_html_e( 'Skip to content', 'barlog' ); ?></a>
	<?php
	do_action( 'barlog/site-start/before' );
	
		/**
		 * Site start
		 *
		 * Hooked
		 *
		 * @see barlog_customize_render_header - 10
		 * @see barlog_Page_Header::render - 35
		 */
		do_action( 'barlog/site-start' );
	
	/**
	 * Hook before main content
	 */
	do_action( 'barlog/before-site-content' );
	?>
	<div id="barlog-site-content" >
		<div>
			<div>
				<?php do_action( 'barlog/main/before' );
