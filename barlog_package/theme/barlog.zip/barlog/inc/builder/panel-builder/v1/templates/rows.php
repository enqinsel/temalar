<script type="text/html" id="tmpl-barlog--cb-panel">
	<div class="barlog--cp-rows">

		<# if ( ! _.isUndefined( data.rows.top ) ) { #>
		<div class="barlog--row-top barlog--cb-row" data-id="{{ data.id }}_top">
			<a class="barlog--cb-row-settings" title="{{ data.rows.top }}" data-id="top" href="#"></a>
			<div class="barlog--row-inner">
				<div class="row--grid">
					<?php
					for ( $i = 1; $i <= 12; $i ++ ) {
						echo '<div></div>';
					}
					?>
				</div>
				<div class="barlog--cb-items grid-stack gridster" data-id="top"></div>
			</div>
		</div>
		<# } #>

		<# if ( ! _.isUndefined( data.rows.main ) ) { #>
		<div class="barlog--row-main barlog--cb-row" data-id="{{ data.id }}_main">
			<a class="barlog--cb-row-settings" title="{{ data.rows.main }}" data-id="main" href="#"></a>

			<div class="barlog--row-inner">
				<div class="row--grid">
					<?php
					for ( $i = 1; $i <= 12; $i ++ ) {
						echo '<div></div>';
					}
					?>
				</div>
				<div class="barlog--cb-items grid-stack gridster" data-id="main"></div>
			</div>
		</div>
		<# } #>


		<# if ( ! _.isUndefined( data.rows.bottom ) ) { #>
		<div class="barlog--row-bottom barlog--cb-row" data-id="{{ data.id }}_bottom">
			<a class="barlog--cb-row-settings" title="{{ data.rows.bottom }}" data-id="bottom" href="#"></a>
			<div class="barlog--row-inner">
				<div class="row--grid">
					<?php
					for ( $i = 1; $i <= 12; $i ++ ) {
						echo '<div></div>';
					}
					?>
				</div>
				<div class="barlog--cb-items grid-stack gridster" data-id="bottom"></div>
			</div>
		</div>
		<# } #>
	</div>


	<# if ( data.device != 'desktop' ) { #>
		<# if ( ! _.isUndefined( data.rows.sidebar ) ) { #>
		<div class="barlog--cp-sidebar">
			<div class="barlog--row-bottom barlog--cb-row" data-id="{{ data.id }}_sidebar">
				<a class="barlog--cb-row-settings" title="{{ data.rows.sidebar }}" data-id="sidebar" href="#"></a>
				<div class="barlog--row-inner">
					<div class="barlog--cb-items barlog--sidebar-items" data-id="sidebar"></div>
				</div>
			</div>
			<div>
		<# } #>
	<# } #>

</script>
