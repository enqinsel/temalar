<?php
if ( ! function_exists( 'barlog_customizer_general_settings_config' ) ) {
	function barlog_customizer_general_settings_config( $configs ) {

		$section = 'barlog_general_settings';

		$config = array(
			array(
				'name'     => 'general_settings_panel',
				'type'     => 'panel',
				'priority' => 22,
				'title'    => esc_html__( 'General Settings', 'barlog' ),
			),

			// Breadcrumbs
			array(
				'name'  => "barlog_general_settings_breadcrumbs",
				'type'  => 'section',
				'panel' => 'general_settings_panel',
				'title' => esc_html__( 'Breadcrumbs', 'barlog' ),
			),

			array(
				'name'            => 'barlog_enable_breadcrumbs',
				'type'            => 'checkbox',
				'section'         => 'barlog_general_settings_breadcrumbs',
				'title'           => esc_html__( 'Breadcrumbs', 'barlog' ),
				'description'     => esc_html__('Enable or disable breadcrumbs', 'barlog'),
				'default'         => 1
			),
			array(
                'name'       	=> 'barlog_breadcrumbs_delimitator',
                'type'     		=> 'text',
				'section'         => 'barlog_general_settings_breadcrumbs',
                'title'    		=> esc_html__('Breadcrumbs delimitator', 'barlog'),
                'description' 	=> esc_html__('(The theme is also compatible with Breadcrumb NavXT plugin, for an enhanced Breadcrumbs / SEO Ready Breadcrumbs feature. Install it and it will automatically replace the default breadcrumbs feature).', 'barlog'),
                'default'  		=> '/'
            ),
			array(
				'name'    		=> 'barlog_breadcrumbs_styling_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_general_settings_breadcrumbs',
				'title'   		=> esc_html__( 'Styling', 'barlog' ),
			),
			array(
				'name'            => 'barlog_breadcrumbs_alignment',
				'type'            => 'text_align_no_justify',
				'section'         => 'barlog_general_settings_breadcrumbs',
				'title'           => esc_html__( 'Alignment', 'barlog' ),
				'default'		  => 'left'	
			),
			array(
				'name'            => 'barlog_breadcrumbs_bg_image',
				'type'            => 'image',
				'section'         => 'barlog_general_settings_breadcrumbs',
				'title'           => esc_html__( 'Background', 'barlog' ),
				'description' 	  => esc_html__('(Change the background color of the breadcrumbs with an image.)', 'barlog'),
				'selector'   	  => ".barlog-breadcrumbs, .youzify-search-landing-image-container",
				'css_format' 	  => 'background-image: url({{value}});',
			),
			array(
				'name'            => 'barlog_enable_parallax',
				'type'            => 'checkbox',
				'section'         => 'barlog_general_settings_breadcrumbs',
				'title'           => esc_html__( 'Parallax', 'barlog' ),
				'description'     => esc_html__('Parallax on background', 'barlog'),
				'default'         => 0
			),
			array(
				'name'        => 'barlog_breadcrumbs_styling',
				'type'        => 'styling',
				'section'     => 'barlog_general_settings_breadcrumbs',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Styling', 'barlog' ),
				'selector'    => array(
					'normal'            => ".barlog-breadcrumbs",
					'hover'             => ".barlog-breadcrumbs:hover"
				),
				'fields'      => array(
					'normal_fields' => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
					'hover_fields'  => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
				),
			),
			array(
				'name'    		=> 'barlog_breadcrumbs_title_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_general_settings_breadcrumbs',
				'title'   		=> esc_html__( 'Breadcrumb Title', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_breadcrumbs_title_color',
				'type'       	=> 'color',
				'section' 		=> 'barlog_general_settings_breadcrumbs',
				'selector'   	=> 'format',
				'title'      	=> esc_html__( 'Title Color', 'barlog' ),
				'selector'   	=> ".barlog-breadcrumbs h2, .barlog-breadcrumbs h1, .barlog-breadcrumbs h1 span",
				'css_format' 	=> 'color: {{value}};',
			),
			array(
				'name'        	=> "barlog_breadcrumbs_title_typo",
				'type'        	=> 'typography',
				'section'     	=> "barlog_general_settings_breadcrumbs",
				'title'       	=> esc_html__( 'Title Typography', 'barlog' ),
				'css_format'  	=> 'typography',
				'selector'    	=> ".barlog-breadcrumbs h2, .barlog-breadcrumbs h1, .barlog-breadcrumbs h1 span",
			),
			array(
				'name'    		=> 'barlog_breadcrumbs_subtitle_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_general_settings_breadcrumbs',
				'title'   		=> esc_html__( 'Breadcrumb Subtitle', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_breadcrumbs_subtitle_color',
				'type'       	=> 'color',
				'section' 		=> 'barlog_general_settings_breadcrumbs',
				'selector'   	=> 'format',
				'title'      	=> esc_html__( 'Subtitle Color', 'barlog' ),
				'selector'   	  => ".barlog-breadcrumbs .breadcrumb .active, .breadcrumb, .breadcrumb a::after,.barlog-breadcrumbs .breadcrumb a",
				'css_format' 	  => 'color: {{value}};',
			),
			array(
				'name'        	=> "barlog_breadcrumbs_subtitle_typo",
				'type'        	=> 'typography',
				'section'     	=> "barlog_general_settings_breadcrumbs",
				'title'       	=> esc_html__( 'Subtitle Typography', 'barlog' ),
				'css_format'  	=> 'typography',
				'selector'    	=> ".barlog-breadcrumbs .breadcrumb .active, .breadcrumb,.barlog-breadcrumbs .breadcrumb a",
			),
			array(
				'name'    			=> 'barlog_breadcrumbs_delimitator_heading',
				'type'    			=> 'heading',
				'section' 			=> 'barlog_general_settings_breadcrumbs',
				'title'   			=> esc_html__( 'Delimitator', 'barlog' ),
			),
			array(
				'name'       		=> 'barlog_breadcrumbs_delimitator_color',
				'type'       		=> 'color',
				'section' 			=> 'barlog_general_settings_breadcrumbs',
				'selector'   		=> 'format',
				'default'			=> 'rgba(0,150,57,0)',
				'title'      		=> esc_html__( 'Delimitator', 'barlog' ),
				'selector'   	  	=> ".barlog-breadcrumbs .row",
				'css_format' 	  	=> 'border-color: {{value}};',
			),

			// Preloader
			array(
				'name'  			=> "barlog_general_settings_preloader",
				'type'  			=> 'section',
				'panel' 			=> 'general_settings_panel',
				'title' 			=> esc_html__( 'Preloader', 'barlog' ),
			),
			array(
				'name'           	=> 'barlog_enable_preloader',
				'type'            	=> 'checkbox',
				'section'         	=> 'barlog_general_settings_preloader',
				'title'           	=> esc_html__( 'Preloader', 'barlog' ),
				'description'     	=> esc_html__('Enable or disable preloader', 'barlog'),
				'default'         	=> 0
			),
			array(
				'name'            	=> 'barlog_preloader_image',
				'type'            	=> 'image',
				'section'         	=> 'barlog_general_settings_preloader',
				'title'           	=> esc_html__( 'Image', 'barlog' )
			),
			array(
				'name'            => 'barlog_preloader_bg_color',
				'type'            => 'color',
				'section'         => 'barlog_general_settings_preloader',
				'title'           => esc_html__( 'Background Color', 'barlog' ),
				'default'         => '#000',
				'selector'    	  => ".barlog_preloader_holder",
				'css_format' 	  => 'background-color: {{value}};'
			),

			// Popup
			array(
				'name'  			=> "barlog_general_settings_popup",
				'type'  			=> 'section',
				'panel' 			=> 'general_settings_panel',
				'title' 			=> esc_html__( 'Popup', 'barlog' ),
			),
			array(
				'name'           	=> 'barlog_enable_popup',
				'type'            	=> 'checkbox',
				'section'         	=> 'barlog_general_settings_popup',
				'title'           	=> esc_html__( 'Popup', 'barlog' ),
				'description'     	=> esc_html__('Enable or disable popup', 'barlog'),
				'default'         	=> 0
			),
			array(
				'name'    			=> 'barlog_popup_design_heading',
				'type'    			=> 'heading',
				'section' 			=> 'barlog_general_settings_popup',
				'title'   			=> esc_html__( 'Design', 'barlog' ),
			),
			array(
				'name'            	=> 'barlog_popup_image',
				'type'            	=> 'image',
				'section'         	=> 'barlog_general_settings_popup',
				'title'           	=> esc_html__( 'Image', 'barlog' ),
				'description' 	  	=> esc_html__('Set your popup image', 'barlog'),
			),
			array(
				'name'            	=> 'barlog_popup_content',
				'type'            	=> 'textarea',
				'section'         	=> 'barlog_general_settings_popup',
				'default'         	=> esc_html__( 'Add custom text here or remove it', 'barlog' ),
				'title'           	=> esc_html__( 'Content', 'barlog' ),
				'description'     	=> esc_html__( 'Set texts and images to the content.', 'barlog' ),
			),
			array(
				'name'    			=> 'barlog_popup_settings_heading',
				'type'    			=> 'heading',
				'section' 			=> 'barlog_general_settings_popup',
				'title'   			=> esc_html__( 'Settings', 'barlog' ),
			),
			array(
                'name'       		=> 'barlog_popup_url',
                'type'     			=> 'text',
                'title'    			=> esc_html__('URL', 'barlog'),
                'section'       	=> 'barlog_general_settings_popup',
            ),
			array(
				'name'            	=> 'barlog_popup_expiring_cookie',
				'type'            	=> 'select',
				'section'         	=> 'barlog_general_settings_popup',
				'title'           	=> esc_html__('Expiring Cookie', 'barlog' ),
				'description'     	=> esc_html__('Select the days for when the cookies to expire.', 'barlog'),
				'choices'         	=> array(
					'1' 	=> esc_html__( '1 Day', 'barlog' ),
					'3'  	=> esc_html__( '3 Days', 'barlog' ),
					'7'  	=> esc_html__( '1 Week', 'barlog' ),
					'30'  	=> esc_html__( '1 Month', 'barlog' ),
					'3000' 	=> esc_html__( 'Be Remembered', 'barlog' ),
				),
				'default'   		=> '1',
			),
			array(
				'name'            	=> 'barlog_popup_show_time',
				'type'            	=> 'select',
				'section'         	=> 'barlog_general_settings_popup',
				'title'           	=> esc_html__('Show Popup', 'barlog' ),
				'description'     	=> esc_html__('Select a specific time to show the popup.', 'barlog'),
				'choices'         	=> array(
					'5000' 	=> esc_html__( '5 seconds', 'barlog' ),
					'10000' => esc_html__( '10 seconds', 'barlog' ),
					'20000' => esc_html__( '20 seconds', 'barlog' )
				),
				'default'   		=> '5000',
			),

            // Contact Information
			array(
				'name'  => "barlog_general_settings_contact",
				'type'  => 'section',
				'panel' => 'general_settings_panel',
				'title' => esc_html__( 'Contact Information', 'barlog' ),
			),

			array(
                'name'       	=> 'barlog_contact_address',
                'type'     		=> 'text',
                'title'    		=> esc_html__('Address', 'barlog'),
                'section'       => 'barlog_general_settings_contact',
            ),
            array(
                'name'       	=> 'barlog_contact_email',
                'type'     		=> 'text',
                'title'    		=> esc_html__('Email', 'barlog'),
                'section'       => 'barlog_general_settings_contact',
            ),
            array(
                'name'       	=> 'barlog_contact_phone',
                'type'     		=> 'text',
                'title'    		=> esc_html__('Phone', 'barlog'),
                'section'       => 'barlog_general_settings_contact',
            ),

			//Back to top
			array(
				'name'  => "barlog_general_settings_back_to_top",
				'type'  => 'section',
				'panel' => 'general_settings_panel',
				'title' => esc_html__( 'Back to Top', 'barlog' ),
			),
			array(
				'name'            => 'barlog_backtotop_status',
				'type'            => 'checkbox',
				'section'         => 'barlog_general_settings_back_to_top',
				'title'           => esc_html__( 'Back to Top Button Status', 'barlog' ),
				'default'         => 1
			),
			array(
				'name'            => 'barlog_backtotop_bg_color',
				'type'            => 'color',
				'section'         => 'barlog_general_settings_back_to_top',
				'title'           => esc_html__( 'Background Color', 'barlog' ),
				'default'         => '#2695FF',
				'selector'    	  => ".barlog-back-to-top",
				'css_format' 	  => 'background-color: {{value}};'
			),
			array(
				'name'            => 'barlog_backtotop_icon_color',
				'type'            => 'color',
				'section'         => 'barlog_general_settings_back_to_top',
				'title'           => esc_html__( 'Icon Color', 'barlog' ),
				'default'         => '#FFF',
				'selector'    	  => ".barlog-back-to-top, .barlog-back-to-top.barlog-is-visible:visited",
				'css_format' 	  => 'color: {{value}};'
			),
			array(
				'name'            => 'barlog_backtotop_bg_color_hover',
				'type'            => 'color',
				'section'         => 'barlog_general_settings_back_to_top',
				'title'           => esc_html__( 'Background Color (Hover)', 'barlog' ),
				'default'         => '#222',
				'selector'    	  => ".barlog-back-to-top:hover",
				'css_format' 	  => 'background-color: {{value}};'
			),
			array(
				'name'            => 'barlog_backtotop_icon_color_hover',
				'type'            => 'color',
				'section'         => 'barlog_general_settings_back_to_top',
				'title'           => esc_html__( 'Icon Color (Hover)', 'barlog' ),
				'default'         => '#FFF',
				'selector'    	  => ".barlog-back-to-top:hover",
				'css_format' 	  => 'color: {{value}};'
			),
			array(
				'name'            	=> 'barlog_backtotop_radius',
				'type'            	=> 'css_ruler',
				'section'    		=> 'barlog_general_settings_back_to_top',
				'device_settings' 	=> true,
				'css_format'      	=> array(
					'top'    => 'border-bottom-right-radius: {{value}};',
					'right'  => 'border-top-right-radius: {{value}};',
					'bottom' => 'border-bottom-left-radius: {{value}};',
					'left'   => 'border-top-left-radius: {{value}};',
				),
				'selector'        	=> "body .barlog-back-to-top",
				'label'           	=> esc_html__( 'Border Radius', 'barlog' ),
			),
		);

		return array_merge( $configs, $config );
	}
}

add_filter( 'barlog/customizer/config', 'barlog_customizer_general_settings_config' );
