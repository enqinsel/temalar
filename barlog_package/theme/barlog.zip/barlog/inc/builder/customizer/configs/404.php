<?php
if ( ! function_exists( 'barlog_customizer_404_config' ) ) {
	function barlog_customizer_404_config( $configs ) {

		$section = 'barlog_not_found';

		$config = array(
			array(
				'name'     => 'not_found_panel',
				'type'     => 'panel',
				'priority' => 22,
				'title'    => esc_html__( '404 Page Settings', 'barlog' ),
			),

			// Image.
			array(
				'name'  => "barlog_not_found_404",
				'type'  => 'section',
				'panel' => 'not_found_panel',
				'title' => esc_html__( '404 Image', 'barlog' ),
			),

			array(
				'name'            => 'barlog_not_found_404_img',
				'type'            => 'image',
				'section'         => 'barlog_not_found_404',
				'title'           => esc_html__( 'Image for 404 Not found page', 'barlog' ),
			),

			// Content.
			array(
				'name'  => "barlog_not_found_404_content",
				'type'  => 'section',
				'panel' => 'not_found_panel',
				'title' => esc_html__( '404 Content', 'barlog' ),
			),
			array(
				'name'            => 'barlog_page_404_heading',
				'type'            => 'textarea',
				'section'         => 'barlog_not_found_404_content',
				'title'           => esc_html__( 'Heading', 'barlog' ),
				'default'         => esc_html__( 'Sorry, this page does not exist!', 'barlog' ),
			),
			array(
				'name'            => 'barlog_page_404_paragraph',
				'type'            => 'textarea',
				'section'         => 'barlog_not_found_404_content',
				'title'           => esc_html__( 'Paragraph (sub-heading)', 'barlog' ),
				'default'         => esc_html__( 'The link you clicked might be corrupted, or the page may have been removed.', 'barlog' ),
			),

		);

		return array_merge( $configs, $config );
	}
}

add_filter( 'barlog/customizer/config', 'barlog_customizer_404_config' );
