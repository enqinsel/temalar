<?php

class Barlog_Builder_Header_Sidebars {
	public $id = 'header_sidebars';

	function customize() {
		$section = 'header_sidebars';

		return array(
			array(
				'name'     => $section,
				'type'     => 'section',
				'panel'    => 'general_settings_panel',
				'priority' => 299,
				'title'    => esc_html__( 'Sidebars', 'barlog' ),
			),
			array(
				'name'             => 'barlog_general_sidebars',
				'type'             => 'repeater',
				'section'        	=> $section,
				'title'            => esc_html__( 'Custom Sidebars', 'barlog' ),
				'live_title_field' => 'title',
				'default'          => array(
					array(
						'title' => esc_html__( 'Header Burger Sidebar', 'barlog' ),
					),
				),
				'fields'           => array(
					array(
						'name'  => 'title',
						'type'  => 'text',
						'label' => esc_html__( 'Sidebar Name', 'barlog' ),
					),
				),
			),
		);
	}
}

Barlog_Customize_Layout_Builder()->register_item( 'header', new Barlog_Builder_Header_Sidebars() );
