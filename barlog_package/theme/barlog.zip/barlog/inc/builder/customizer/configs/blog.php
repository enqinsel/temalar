<?php
if ( ! function_exists( 'barlog_customizer_blog_config' ) ) {
	function barlog_customizer_blog_config( $configs ) {

		$section = 'barlog_blog';

		$config = array(
			// Panel
			array(
				'name'     => 'blog_panel',
				'type'     => 'panel',
				'priority' => 22,
				'title'    => esc_html__( 'Blog Settings', 'barlog' ),
			),

			// I. Blog Archive
			array(
				'name'  => "barlog_blog_archive",
				'type'  => 'section',
				'panel' => 'blog_panel',
				'title' => esc_html__( 'Blog Archive', 'barlog' ),
			),
			array(
				'name'            => 'barlog_blog_archive_layout',
				'type'            => 'radio_group',
				'section'         => 'barlog_blog_archive',
				'default'         => 'right-sidebar',
				'title'           => esc_html__( 'Blog Layout', 'barlog' ),
				'choices'         => array(
					'left-sidebar'  	=> esc_html__( 'Left Sidebar', 'barlog' ),
					'no-sidebar' 		=> esc_html__( 'Fullwidth', 'barlog' ),
					'right-sidebar'  	=> esc_html__( 'Right Sidebar', 'barlog' ),
				),
			),
			array(
				'name'        => 'barlog_blog_article_card_styling',
				'type'        => 'styling',
				'section'     => 'barlog_blog_archive',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Article Card Styling', 'barlog' ),
				'selector'    => '.barlog-article-wrapper .barlog-article-inner',
				'fields'      => array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					)
				)
			),

			// II. Single Post
			array(
				'name'  => "barlog_blog_single",
				'type'  => 'section',
				'panel' => 'blog_panel',
				'title' => esc_html__( 'Blog Single Article', 'barlog' ),
			),
			array(
				'name'            => 'barlog_blog_single_layout',
				'type'            => 'radio_group',
				'section'         => 'barlog_blog_single',
				'default'         => 'no-sidebar',
				'title'           => esc_html__( 'Single Blog Layout', 'barlog' ),
				'choices'         => array(
					'left-sidebar'  	=> esc_html__( 'Left Sidebar', 'barlog' ),
					'no-sidebar' 		=> esc_html__( 'Fullwidth', 'barlog' ),
					'right-sidebar'  	=> esc_html__( 'Right Sidebar', 'barlog' ),
				),
			),
			array(
				'name'            => 'barlog_blog_single_featured_image',
				'type'            => 'checkbox',
				'section'         => 'barlog_blog_single',
				'default'         => 1,
				'title'           => esc_html__( 'Featured Image', 'barlog' ),
				'description'     => esc_html__( 'Show or Hide the featured image from blog post page', 'barlog' ),
			),
		);

		return array_merge( $configs, $config );
	}
}

add_filter( 'barlog/customizer/config', 'barlog_customizer_blog_config' );
