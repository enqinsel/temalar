<?php
if ( ! function_exists( 'barlog_customizer_styling_config' ) ) {
	function barlog_customizer_styling_config( $configs ) {
		$barlog_buttons = barlog_get_customizer_buttons_styling();
		$barlog_buttons_hover = barlog_get_customizer_buttons_hover_styling();
		$barlog_fields = barlog_get_customizer_fields_styling();
		$barlog_fields_focus = barlog_get_customizer_fields_styling_focus();
		$section = 'barlog_styling_settings';
		$config = array(
			array(
				'name'     => 'styling_settings_panel',
				'type'     => 'panel',
				'priority' => 22,
				'title'    => esc_html__( 'Styling Settings', 'barlog' ),
			),

			// I. General Tab
			array(
				'name'  => "barlog_styling_settings_color",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'General Site Colors', 'barlog' ),
			),
			array(
				'name'    		=> 'barlog_styling_settings_color_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_styling_settings_color',
				'title'   		=> esc_html__( 'Links Color Option', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_color_links_normal',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_color',
				'selector'   	=> 'format',
				'default'		=> '#222',
				'title'      	=> esc_html__( 'Regular', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_color_links_hover',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_color',
				'selector'   	=> 'format',
				'title'      	=> esc_html__( 'Hover', 'barlog' ),
			),
			array(
				'name'    => 'barlog_styling_settings_color_links_weight',
				'type'    => 'select',
				'section' => 'barlog_styling_settings_color',
				'label'   => esc_html__( 'Weight', 'barlog' ),
				'choices' => array(
					'default'   => esc_html__( 'Default', 'barlog' ),
					'bold' 		=> esc_html__( 'Bold', 'barlog' ),
					'100'  		=> esc_html__( '100', 'barlog' ),
					'200'  		=> esc_html__( '200', 'barlog' ),
					'300' 		=> esc_html__( '300', 'barlog' ),
					'400' 		=> esc_html__( '400', 'barlog' ),
					'500' 		=> esc_html__( '500', 'barlog' ),
					'600' 		=> esc_html__( '600', 'barlog' ),
					'700' 		=> esc_html__( '700', 'barlog' ),
					'800' 		=> esc_html__( '800', 'barlog' ),
				)
			),

			// 1. Main colors and Background
			array(
				'name'    		=> 'barlog_styling_settings_color_bg_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_styling_settings_color',
				'title'   		=> esc_html__( 'Main colors & Background', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_color_text_color',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#2695ff',
				'title'      	=> esc_html__( 'Text color', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_main_bg_color',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#2695ff',
				'title'      	=> esc_html__( 'Background color', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_main_border_color',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#2695ff',
				'title'      	=> esc_html__( 'Border color', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_main_bg_color_hover',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#ffffff',
				'title'      	=> esc_html__( 'Background color (hover)', 'barlog' ),
			),

			// 2. Text selection
			array(
				'name'    		=> 'barlog_styling_settings_text_selection_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_styling_settings_color',
				'title'   		=> esc_html__( 'Text Selection Color & Background', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_selection_color',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#ffffff',
				'title'      	=> esc_html__( 'Color', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_selection_bg',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_color',
				'selector'   	=> 'format',
				'default'   	=> '#2695ff',
				'title'      	=> esc_html__( 'Background color', 'barlog' ),
			),
			array(
				'name'    		=> 'barlog_styling_settings_paragraph_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_styling_settings_color',
				'title'   		=> esc_html__( 'Body & Paragraphs Color', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_color_body_color',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_color',
				'selector'    	=> 'body',
				'css_format' 	=> 'color: {{value}};',
				'default'		=> '#6a6b76',
				'title'      	=> esc_html__( 'Color', 'barlog' ),
			),

			// 3. Menu Styling Tab
			array(
				'name'  => "barlog_styling_settings_navigation",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'Primary Menu Styling', 'barlog' ),
			),
			// a. Main Navigation
			array(
				'name'    		=> 'barlog_styling_settings_main_navigation_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_styling_settings_navigation',
				'title'   		=> esc_html__( 'Main Navigation', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_main_text_color',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_navigation',
				'selector'   	=> '.builder-item--primary-menu .nav-menu-desktop .menu>li>a',
				'css_format' 	=> 'color: {{value}};',
				'title'      	=> esc_html__( 'Text Color', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_main_text_color_hover',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_navigation',
				'selector'   	=> '.builder-item--primary-menu .nav-menu-desktop .menu>li>a:hover',
				'css_format' 	=> 'color: {{value}};',
				'title'      	=> esc_html__( 'Hover Text Color', 'barlog' ),
			),
			// b. Submenu Navigation
			array(
				'name'    		=> 'barlog_styling_settings_submenu_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_styling_settings_navigation',
				'title'   		=> esc_html__( 'Submenus Styling', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_submenu_background',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_navigation',
				'selector'    	=> ".nav-menu-desktop .sub-menu li a",
				'css_format' 	=> 'background-color: {{value}};',
				'title'      	=> esc_html__( 'Background Color', 'barlog' ),
				'default'   	=> '#FFF',
			),
			array(
				'name'       	=> 'barlog_styling_settings_submenu_text_color',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_navigation',
				'selector'    	=> ".nav-menu-desktop .sub-menu li a",
				'css_format' 	=> 'color: {{value}};',
				'title'      	=> esc_html__( 'Text Color', 'barlog' ),
				'default'   	=> '#484848',
			),
			array(
				'name'       	=> 'barlog_styling_settings_submenu_background_hover',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_navigation',
				'selector'    	=> ".nav-menu-desktop .sub-menu li a:hover",
				'css_format' 	=> 'background-color: {{value}};',
				'title'      	=> esc_html__( 'Hover Background Color', 'barlog' ),
				'default'   	=> '#FFF',
			),
			array(
				'name'       	=> 'barlog_styling_settings_submenu_text_color_hover',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_navigation',
				'selector'    	=> ".nav-menu-desktop .sub-menu li a:hover",
				'css_format' 	=> 'color: {{value}};',
				'title'      	=> esc_html__( 'Hover Text Color', 'barlog' ),
				'default'   	=> '#2695ff',
			),
			array(
				'name'       	=> 'barlog_styling_settings_submenu_border_color_hover',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_navigation',
				'selector'    	=> ".nav-menu-desktop .sub-menu li",
				'css_format' 	=> 'border-bottom: 1px solid {{value}} !important;',
				'title'      	=> esc_html__( 'Border Color', 'barlog' ),
				'default'   	=> '#ddd',
			),
			array(
				'name'        => 'barlog_styling_settings_submenu_padding',
				'type'        => 'styling',
				'section'     => 'barlog_styling_settings_navigation',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Styling Items', 'barlog' ),
				'selector'    => array(
					'normal'            => ".nav-menu-desktop .sub-menu li a",
					'hover'             => ".nav-menu-desktop .sub-menu li a:hover"
				),
				'fields'      => array(
					'normal_fields' => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
					'hover_fields'  => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
				),
			),
			array(
				'name'        => 'barlog_styling_settings_submenu_dropdown',
				'type'        => 'styling',
				'section'     => 'barlog_styling_settings_navigation',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Styling Dropdown', 'barlog' ),
				'selector'    => array(
					'normal'            => ".nav-menu-desktop .sub-menu",
					'hover'             => ".nav-menu-desktop .sub-menu:hover"
				),
				'fields'      => array(
					'normal_fields' => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
					'hover_fields'  => array(
						'text_color'    => false,
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
						'border'		=> false,
						'border_radius' => false,
						'box_shadow' 	=> false,
						'border_style' 	=> false,
					),
				),
			),

			// Mega Menu
			array(
				'name'  => "barlog_styling_settings_mega_menu",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'Mega Menu', 'barlog' ),
			),
			// a. Main Navigation
			array(
				'name'    		=> 'barlog_styling_settings_mega_menu_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_styling_settings_mega_menu',
				'title'   		=> esc_html__( 'Styling', 'barlog' ),
			),
			array(
				'name'       	=> 'barlog_styling_settings_mega_menu_color',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_mega_menu',
				'title'      	=> esc_html__( 'Links Color', 'barlog' ),
				'selector'    	=> ".cf-mega-menu.sub-menu a",
				'css_format' 	=> 'color: {{value}};',
			),
			array(
				'name'       	=> 'barlog_styling_settings_mega_menu_hover',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_mega_menu',
				'title'      	=> esc_html__( 'Links Hover', 'barlog' ),
				'selector'    	=> ".cf-mega-menu.sub-menu a:hover",
				'css_format' 	=> 'color: {{value}};',
			),
			array(
				'name'            => 'barlog_styling_settings_mega_menu_width',
				'type'            => 'slider',
				'device_settings' => true,
				'section' 		  => 'barlog_styling_settings_mega_menu',
				'selector'        => ".cf-mega-menu.sub-menu",
				'css_format'      => 'width: {{value}};',
				'label'           => esc_html__( 'Width', 'barlog' ),
			),

			// III. Buttons Tab
			array(
				'name'  => "barlog_styling_settings_buttons",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'Buttons', 'barlog' ),
			),
			array(
				'name'        => "barlog_styling_settings_buttons_typo",
				'type'        => 'typography',
				'section'     => "barlog_styling_settings_buttons",
				'title'       => esc_html__( 'Typography', 'barlog' ),
				'description' => esc_html__( 'Apply to buttons text.', 'barlog' ),
				'css_format'  => 'typography',
				'selector'    => "{$barlog_buttons}",
			), 
			array(
				'name'        => 'barlog_styling_settings_buttons_styling',
				'type'        => 'styling',
				'section'     => 'barlog_styling_settings_buttons',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Button Styling', 'barlog' ),
				'selector'    => array(
					'normal'            => "{$barlog_buttons}",
					'hover'             => "{$barlog_buttons_hover}",
				),
				'fields'      => array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					),
					'hover_fields'  => array(
						'link_color'    => false,
						'padding'       => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'border_radius' => false,
					),
				)
			),
			

			// IV. Fields Tab
			array(
				'name'  => "barlog_styling_settings_fields",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'Fields', 'barlog' ),
			),
			array(
				'name'        => 'barlog_styling_settings_fields_styling',
				'type'        => 'styling',
				'section'     => 'barlog_styling_settings_fields',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Fields Styling', 'barlog' ),
				'selector'    => array(
					'normal'            => "{$barlog_fields}"
				),
				'fields'      => array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					)
				)
			),
			array(
				'name'        => "barlog_styling_settings_fields_typo",
				'type'        => 'typography',
				'section'     => "barlog_styling_settings_fields",
				'title'       => esc_html__( 'Typography', 'barlog' ),
				'description' => esc_html__( 'Apply to fields text.', 'barlog' ),
				'css_format'  => 'typography',
				'selector'    => "{$barlog_fields}",
			),
			array(
				'name'       	=> 'barlog_styling_settings_fields_styling_focus',
				'type'       	=> 'color',
				'section' 		=> 'barlog_styling_settings_fields',
				'selector'    	=> "{$barlog_fields_focus}",
				'css_format' 	=> 'border-color: {{value}};',
				'title'      	=> esc_html__( 'Fields Color on Focus', 'barlog' ),
				'default'   	=> '#d3d3d3',
			),
			// IV. Typography
			array(
				'name'  => "barlog_styling_settings_typo",
				'type'  => 'section',
				'panel' => 'styling_settings_panel',
				'title' => esc_html__( 'Site Typography', 'barlog' ),
			),
			array(
				'name'        => "barlog_styling_settings_body_typo",
				'type'        => 'typography',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Body Font family', 'barlog' ),
				'css_format'  => 'typography',
				'selector'    => "body, ul li, ol li, p",
			),
			array(
				'name'        => "barlog_styling_settings_h1_typo",
				'type'        => 'typography',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H1', 'barlog' ),
				'css_format'  => 'typography',
				'selector'    => "h1, h1 span",
			),
			array(
				'name'        => "barlog_styling_settings_h2_typo",
				'type'        => 'typography',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H2', 'barlog' ),
				'css_format'  => 'typography',
				'selector'    => "h2",
			),
			array(
				'name'        => "barlog_styling_settings_h3_typo",
				'type'        => 'typography',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H3', 'barlog' ),
				'css_format'  => 'typography',
				'selector'    => "h3, .post-name, .barlog-post-name a",
			),
			array(
				'name'        => "barlog_styling_settings_h4_typo",
				'type'        => 'typography',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H4', 'barlog' ),
				'css_format'  => 'typography',
				'selector'    => "h4",
			),
			array(
				'name'        => "barlog_styling_settings_h5_typo",
				'type'        => 'typography',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H5', 'barlog' ),
				'css_format'  => 'typography',
				'selector'    => "h5",
			),
			array(
				'name'        => "barlog_styling_settings_h6_typo",
				'type'        => 'typography',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H6', 'barlog' ),
				'css_format'  => 'typography',
				'selector'    => "h6",
			),
			array(
				'name'    		=> 'barlog_styling_settings_mobile_typo_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_styling_settings_typo',
				'title'   		=> esc_html__( 'Mobile Typography', 'barlog' ),
			),
			array(
				'name'        => "barlog_styling_settings_h1_size_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H1 Font size', 'barlog' ),
				'default'	  => '26px',
			),
			array(
				'name'        => "barlog_styling_settings_h1_lh_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H1 Line height', 'barlog' ),
				'default'	  => '38px',
			),
			array(
				'name'        => "barlog_styling_settings_h2_size_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H2 Font size', 'barlog' ),
				'default'	  => '24px',
			),
			array(
				'name'        => "barlog_styling_settings_h2_lh_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H2 Line height', 'barlog' ),
				'default'	  => '28px',
			),
			array(
				'name'        => "barlog_styling_settings_h3_size_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H3 Font size', 'barlog' ),
				'default'	  => '22px',
			),
			array(
				'name'        => "barlog_styling_settings_h3_lh_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H3 Line height', 'barlog' ),
				'default'	  => '26px',
			),
			array(
				'name'        => "barlog_styling_settings_h4_size_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H4 Font size', 'barlog' ),
				'default'	  => '20px',
			),
			array(
				'name'        => "barlog_styling_settings_h4_lh_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H4 Line height', 'barlog' ),
				'default'	  => '24px',
			),
			array(
				'name'        => "barlog_styling_settings_h5_size_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H5 Font size', 'barlog' ),
				'default'	  => '18px',
			),
			array(
				'name'        => "barlog_styling_settings_h5_lh_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H5 Line height', 'barlog' ),
				'default'	  => '22px',
			),
			array(
				'name'        => "barlog_styling_settings_h6_size_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H6 Font size', 'barlog' ),
				'default'	  => '16px',
			),
			array(
				'name'        => "barlog_styling_settings_h6_lh_mobile",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H6 Line height', 'barlog' ),
				'default'	  => '20px',
			),
			array(
				'name'    		=> 'barlog_styling_settings_tablet_typo_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_styling_settings_typo',
				'title'   		=> esc_html__( 'Tablet Typography', 'barlog' ),
			),
			array(
				'name'        => "barlog_styling_settings_h1_size_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H1 Font size', 'barlog' ),
				'default'	  => '28px',
			),
			array(
				'name'        => "barlog_styling_settings_h1_lh_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H1 Line height', 'barlog' ),
				'default'	  => '32px',
			),
			array(
				'name'        => "barlog_styling_settings_h2_size_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H2 Font size', 'barlog' ),
				'default'	  => '26px',
			),
			array(
				'name'        => "barlog_styling_settings_h2_lh_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H2 Line height', 'barlog' ),
				'default'	  => '30px',
			),
			array(
				'name'        => "barlog_styling_settings_h3_size_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H3 Font size', 'barlog' ),
				'default'	  => '24px',
			),
			array(
				'name'        => "barlog_styling_settings_h3_lh_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H3 Line height', 'barlog' ),
				'default'	  => '28px',
			),
			array(
				'name'        => "barlog_styling_settings_h4_size_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H4 Font size', 'barlog' ),
				'default'	  => '22px',
			),
			array(
				'name'        => "barlog_styling_settings_h4_lh_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H4 Line height', 'barlog' ),
				'default'	  => '26px',
			),
			array(
				'name'        => "barlog_styling_settings_h5_size_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H5 Font size', 'barlog' ),
				'default'	  => '20px',
			),
			array(
				'name'        => "barlog_styling_settings_h5_lh_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H5 Line height', 'barlog' ),
				'default'	  => '23px',
			),
			array(
				'name'        => "barlog_styling_settings_h6_size_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H6 Font size', 'barlog' ),
				'default'	  => '18px',
			),
			array(
				'name'        => "barlog_styling_settings_h6_lh_tablet",
				'type'        => 'text',
				'section'     => "barlog_styling_settings_typo",
				'title'       => esc_html__( 'Heading H6 Line height', 'barlog' ),
				'default'	  => '21px',
			),

			// IV. Typography
			array(
				'name'  	=> "barlog_styling_settings_widgets",
				'type'  	=> 'section',
				'panel' 	=> 'styling_settings_panel',
				'title' 	=> esc_html__( 'Widgets Styling', 'barlog' ),
			),
			array(
				'name'    	=> 'barlog_styling_widgets_heading_1',
				'type'    	=> 'heading',
				'section' 	=> 'barlog_styling_settings_widgets',
				'title'   	=> esc_html__( 'Sidebar Widgets', 'barlog' ),
			),
			array(
				'name'        => 'barlog_blog_widget_card_styling',
				'type'        => 'styling',
				'section'     => 'barlog_styling_settings_widgets',
				'css_format'  => 'styling',
				'title'       => esc_html__( 'Card Styling', 'barlog' ),
				'selector'    => '.sidebar-content .widget',
				'fields'      => array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					)
				)
			),
			array(
				'name'        => 'barlog_blog_sidebar_title_styling',
				'type'        => 'typography',
				'section'     => 'barlog_styling_settings_widgets',
				'css_format'  => 'typography',
				'title'       => esc_html__( 'Title Typography', 'barlog' ),
				'selector'    => '.sidebar-content .widget-title, .sidebar-content .widget h2, .sidebar-content .widget .wp-block-search__label'
			),
			array(
				'name'    		=> 'barlog_styling_widgets_social_heading',
				'type'    		=> 'heading',
				'section' 		=> 'barlog_styling_settings_widgets',
				'title'   		=> esc_html__( 'Widget: MT - Contact + Social Media', 'barlog' ),
			),
			array(
				'name'        	=> 'barlog_widget_contact_styling',
				'type'       	=> 'color',
				'section'     	=> 'barlog_styling_settings_widgets',
				'title'       	=> esc_html__( 'Contact Links Styling', 'barlog' ),
				'css_format' 	=> 'color: {{value}};',
				'selector'    	=> '.contact-details span, .contact-details span i',
			),
			array(
				'name'        	=> 'barlog_widget_social_media_styling',
				'type'        	=> 'styling',
				'section'     	=> 'barlog_styling_settings_widgets',
				'css_format'  	=> 'styling',
				'title'       	=> esc_html__( 'Social Icon Styling', 'barlog' ),
				'selector'    	=> array(
					'normal'        => ".widget_mt_address_social_icons a",
					'hover'         => ".widget_mt_address_social_icons a:hover",
				),
				'fields'      	=> array(
					'normal_fields' => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					),
					'hover_fields'  => array(
						'link_color'    => false,
						'bg_cover'      => false,
						'bg_image'      => false,
						'bg_repeat'     => false,
						'bg_attachment' => false,
						'margin'        => false,
					)
				)
			)
		);

		return array_merge( $configs, $config );
	}
}

add_filter( 'barlog/customizer/config', 'barlog_customizer_styling_config' );
