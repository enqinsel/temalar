<?php

class Barlog_Builder_Footer extends Barlog_Customize_Builder_Panel {
	public $id = 'footer';

	function get_config() {
		return array(
			'id'         => 'footer',
			'title'      => esc_html__( 'Footer Builder', 'barlog' ),
			'control_id' => 'footer_builder_panel',
			'panel'      => 'footer_settings',
			'section'    => 'footer_builder_panel',
			'devices'    => array(
				'desktop' => esc_html__( 'Footer Layout', 'barlog' ),
			),
		);
	}

	function get_rows_config() {
		return array(
			'main'   => esc_html__( 'Footer Main', 'barlog' ),
			'bottom' => esc_html__( 'Footer Bottom', 'barlog' ),
		);
	}

	function customize() {
		$fn     = 'barlog_customize_render_footer';
		$config = array(
			array(
				'name'     => 'footer_settings',
				'type'     => 'panel',
				'priority' => 98,
				'title'    => esc_html__( 'Footer', 'barlog' ),
			),

			array(
				'name'  => 'footer_builder_panel',
				'type'  => 'section',
				'panel' => 'footer_settings',
				'title' => esc_html__( 'Footer Builder', 'barlog' ),
			),

			array(
				'name'                => 'footer_builder_panel',
				'type'                => 'js_raw',
				'section'             => 'footer_builder_panel',
				'theme_supports'      => '',
				'title'               => esc_html__( 'Footer Builder', 'barlog' ),
				'selector'            => '#site-footer',
				'render_callback'     => $fn,
				'container_inclusive' => true,
			),

		);

		return $config;
	}

	function row_config( $section = false, $section_name = false ) {
		$selector           = '#cb-row--' . str_replace( '_', '-', $section );
		$skin_mode_selector = '.footer--row-inner.' . str_replace( '_', '-', $section ) . '-inner';

		$fn = 'barlog_customize_render_footer';

		$config = array(
			array(
				'name'           => $section,
				'type'           => 'section',
				'panel'          => 'footer_settings',
				'theme_supports' => '',
				'title'          => $section_name,
			),

			array(
				'name'            => $section . '_layout',
				'type'            => 'select',
				'section'         => $section,
				'title'           => esc_html__( 'Layout', 'barlog' ),
				'selector'        => $selector,
				'render_callback' => $fn,
				'css_format'      => 'html_class',
				'default'         => 'layout-full-contained',
				'choices'         => array(
					'layout-full-contained' => esc_html__( 'Full width - Contained', 'barlog' ),
					'layout-fullwidth'      => esc_html__( 'Full Width', 'barlog' ),
					'layout-contained'      => esc_html__( 'Contained', 'barlog' ),
				),
			),
			array(
				'name'       => "{$section}_background_color",
				'type'       => 'color',
				'section'    => $section,
				'title'      => esc_html__( 'Background Color', 'barlog' ),
				'selector'   => "{$selector} .footer--row-inner",
				'css_format' => 'background-color: {{value}}',
			),
			array(
				'name'       => "{$section}_title_typography",
				'type'       => 'typography',
				'section'    => $section,
				'title'      => esc_html__( 'Menu Typography', 'barlog' ),
				'selector'   => "{$selector} .footer--row-inner .widget-title",
				'css_format' => 'typography',
			),
			array(
				'name'       => "{$section}_title_color",
				'type'       => 'color',
				'section'    => $section,
				'title'      => esc_html__( 'Menu Title', 'barlog' ),
				'selector'   => "{$selector} .footer--row-inner .widget-title",
				'css_format' => 'color: {{value}}',
			),
			array(
				'name'       => "{$section}_items_color",
				'type'       => 'color',
				'section'    => $section,
				'title'      => esc_html__( 'Menu Items', 'barlog' ),
				'selector'   => "{$selector} .footer--row-inner .menu-item a",
				'css_format' => 'color: {{value}}',
			),
			array(
				'name'       => "{$section}_items_color_hover",
				'type'       => 'color',
				'section'    => $section,
				'title'      => esc_html__( 'Menu Items (Hover)', 'barlog' ),
				'selector'   => "{$selector} .footer--row-inner .menu-item a:hover",
				'css_format' => 'color: {{value}}',
			),
			array(
				'name'       => "{$section}_separator_color",
				'type'       => 'color',
				'section'    => $section,
				'title'      => esc_html__( 'Separator', 'barlog' ),
				'selector'   => "{$selector} .footer--row-inner .container",
				'css_format' => 'border-color: {{value}}',
			),
			array(
				'name'       	=> "{$section}_mobile_aligment",
				'type'          => 'text_align_no_justify',
				'section'    	=> $section,
				'title'         => esc_html__( 'Mobile Alignment', 'barlog' ),
				'default'		=> 'left',
				'selector'      => "@media screen and (max-width: 1170px) { {$selector} div",
				'css_format' 	=> "text-align: {{value}};}",	
			),
		);
		$config = apply_filters( 'barlog/builder/' . $this->id . '/rows/section_configs', $config, $section, $section_name );
		return $config;
	}
}

function barlog_footer_layout_settings( $item_id, $section ) {

	global $wp_customize;

	if ( is_object( $wp_customize ) ) {
		global $wp_registered_sidebars;
		$name = $section;
		if ( is_array( $wp_registered_sidebars ) ) {
			if ( isset( $wp_registered_sidebars[ $item_id ] ) ) {
				$name = $wp_registered_sidebars[ $item_id ]['name'];
			}
		}
		$wp_customize->add_section(
			$section,
			array(
				'title' => $name,
			)
		);
	}

	if ( function_exists( 'barlog_header_layout_settings' ) ) {
		return barlog_header_layout_settings( $item_id, $section, 'barlog_customize_render_footer', 'footer_' );
	}

	return false;
}

Barlog_Customize_Layout_Builder()->register_builder( 'footer', new Barlog_Builder_Footer() );



