<?php
if ( ! function_exists( 'barlog_customizer_social_media_config' ) ) {
	function barlog_customizer_social_media_config( $configs ) {

		$section = 'barlog_social_media';

		$config = array(
			array(
				'name'     => 'social_media_panel',
				'type'     => 'panel',
				'priority' => 22,
				'title'    => esc_html__( 'Social Media', 'barlog' ),
			),

			// Social Shares Tab.
			array(
				'name'  => "barlog_social_media_shares",
				'type'  => 'section',
				'panel' => 'social_media_panel',
				'title' => esc_html__( 'Social Shares', 'barlog' ),
			),

			array(
				'name'            => 'barlog_social_media_shares_twitter',
				'type'            => 'checkbox',
				'section'         => 'barlog_social_media_shares',
				'title'           => esc_html__( 'Twitter', 'barlog' ),
			),

			array(
				'name'            => 'barlog_social_media_shares_facebook',
				'type'            => 'checkbox',
				'section'         => 'barlog_social_media_shares',
				'title'           => esc_html__( 'Facebook', 'barlog' ),
			),

			array(
				'name'            => 'barlog_social_media_shares_whatsapp',
				'type'            => 'checkbox',
				'section'         => 'barlog_social_media_shares',
				'title'           => esc_html__( 'Whatsapp', 'barlog' ),
			),

			array(
				'name'            => 'barlog_social_media_shares_pinterest',
				'type'            => 'checkbox',
				'section'         => 'barlog_social_media_shares',
				'title'           => esc_html__( 'Pinterest', 'barlog' ),
			),

			array(
				'name'            => 'barlog_social_media_shares_linkedin',
				'type'            => 'checkbox',
				'section'         => 'barlog_social_media_shares',
				'title'           => esc_html__( 'Linkedin', 'barlog' ),
			),

			array(
				'name'            => 'barlog_social_media_shares_telegram',
				'type'            => 'checkbox',
				'section'         => 'barlog_social_media_shares',
				'title'           => esc_html__( 'Telegram', 'barlog' ),
			),

			array(
				'name'            => 'barlog_social_media_shares_email',
				'type'            => 'checkbox',
				'section'         => 'barlog_social_media_shares',
				'title'           => esc_html__( 'Email', 'barlog' ),
			),

			// Social Links Tab.
			array(
				'name'  => "barlog_social_media_links",
				'type'  => 'section',
				'panel' => 'social_media_panel',
				'title' => esc_html__( 'Social Links', 'barlog' ),
			),

			array(
				'name'            => 'barlog_social_media_links_twitter',
				'type'            => 'text',
				'section'         => 'barlog_social_media_links',
				'title'           => esc_html__( 'Twitter', 'barlog' ),
			),
			array(
				'name'            => 'barlog_social_media_links_facebook',
				'type'            => 'text',
				'section'         => 'barlog_social_media_links',
				'title'           => esc_html__( 'Facebook', 'barlog' ),
			),
			array(
				'name'            => 'barlog_social_media_links_youtube',
				'type'            => 'text',
				'section'         => 'barlog_social_media_links',
				'title'           => esc_html__( 'Youtube', 'barlog' ),
			),
			array(
				'name'            => 'barlog_social_media_links_pinterest',
				'type'            => 'text',
				'section'         => 'barlog_social_media_links',
				'title'           => esc_html__( 'Pinterest', 'barlog' ),
			),
			array(
				'name'            => 'barlog_social_media_links_linkedin',
				'type'            => 'text',
				'section'         => 'barlog_social_media_links',
				'title'           => esc_html__( 'Linkedin', 'barlog' ),
			),
			array(
				'name'            => 'barlog_social_media_links_skype',
				'type'            => 'text',
				'section'         => 'barlog_social_media_links',
				'title'           => esc_html__( 'Skype', 'barlog' ),
			),
			array(
				'name'            => 'barlog_social_media_links_instagram',
				'type'            => 'text',
				'section'         => 'barlog_social_media_links',
				'title'           => esc_html__( 'Instagram', 'barlog' ),
			),
			array(
				'name'            => 'barlog_social_media_links_dribble',
				'type'            => 'text',
				'section'         => 'barlog_social_media_links',
				'title'           => esc_html__( 'Dribble', 'barlog' ),
			),
			array(
				'name'            => 'barlog_social_media_links_vimeo',
				'type'            => 'text',
				'section'         => 'barlog_social_media_links',
				'title'           => esc_html__( 'Vimeo', 'barlog' ),
			),
		);

		return array_merge( $configs, $config );
	}
}

add_filter( 'barlog/customizer/config', 'barlog_customizer_social_media_config' );
