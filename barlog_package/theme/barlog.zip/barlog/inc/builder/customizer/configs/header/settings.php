<?php

class Barlog_Builder_Header_Settings {
	public $id = 'header_settings';

	function customize() {
		$section = 'header_settings';

		return array(
			array(
				'name'     		=> $section,
				'type'     		=> 'section',
				'panel'    		=> 'header_settings',
				'priority' 		=> 299,
				'title'    		=> esc_html__( 'Settings', 'barlog' ),
			),
			array(
				'name'          => 'barlog_general_settings_look_htransparent',
				'type'          => 'checkbox',
				'section'   	=> $section,
				'title'         => esc_html__( 'Transparent Header', 'barlog' ),
				'description'   => esc_html__('Enable or disable Transparent Header', 'barlog'),
				'default'       => 0,
			),
			array(
				'name'      	=> 'barlog_is_nav_sticky',
				'type'      	=> 'checkbox',
				'section'   	=> $section,
				'title'     	=> esc_html__( 'Fixed Navigation menu?', 'barlog' ),
				'description'   => esc_html__('Enable or disable Sticky Header', 'barlog'),
			),
		);
	}
}

Barlog_Customize_Layout_Builder()->register_item( 'header', new Barlog_Builder_Header_Settings() );
