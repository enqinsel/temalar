<?php
class Barlog_Customizer_Control_Font extends Barlog_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-barlog-css-ruler">
		<?php
		self::before_field();
		?>
		<?php echo self::field_header(); ?>
		<div class="barlog-field-settings-inner">
			<input type="hidden" class="barlog--font-type" data-name="{{ field.name }}-type" >
			<div class="barlog--font-families-wrapper">
				<select class="barlog--font-families" data-value="{{ JSON.stringify( field.value ) }}" data-name="{{ field.name }}-font"></select>
			</div>
			<div class="barlog--font-variants-wrapper">
				<label><?php _e( 'Variants', 'barlog' ); ?></label>
				<select class="barlog--font-variants" data-name="{{ field.name }}-variant"></select>
			</div>
			<div class="barlog--font-subsets-wrapper">
				<label><?php _e( 'Languages', 'barlog' ); ?></label>
				<div data-name="{{ field.name }}-subsets" class="list-subsets">
				</div>
			</div>
		</div>
		<?php
		self::after_field();
		?>
		</script>
		<?php
	}
}
