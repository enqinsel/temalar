<?php
class Barlog_Customizer_Control_Styling extends Barlog_Customizer_Control_Modal {
	static function field_template() {
		echo '<script type="text/html" id="tmpl-field-barlog-styling">';
		self::before_field();
		?>
		<?php echo self::field_header(); ?>
		<div class="barlog-actions">
			<a href="#" title="<?php esc_attr_e( 'Reset to default', 'barlog' ); ?>" class="action--reset" data-control="{{ field.name }}"><span class="dashicons dashicons-image-rotate"></span></a>
			<a href="#" title="<?php esc_attr_e( 'Toggle edit panel', 'barlog' ); ?>" class="action--edit" data-control="{{ field.name }}"><span class="dashicons dashicons-admin-customizer"></span></a>
		</div>
		<div class="barlog-field-settings-inner">
			<input type="hidden" class="barlog-hidden-modal-input barlog-only" data-name="{{ field.name }}" value="{{ JSON.stringify( field.value ) }}" data-default="{{ JSON.stringify( field.default ) }}">
		</div>
		<?php
		self::after_field();
		echo '</script>';
		?>
		<script type="text/html" id="tmpl-barlog-modal-settings">
			<div class="barlog-modal-settings">
				<div class="barlog-modal-settings--inner">
					<div class="barlog-modal-settings--fields"></div>
				</div>
			</div>
		</script>
		<?php
	}
}
