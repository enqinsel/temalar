<?php
class Barlog_Customizer_Control_Heading extends Barlog_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-barlog-heading">
		<?php
		self::before_field();
		?>
		<h3 class="barlog-field--heading">{{ field.label }}</h3>
		<?php
		self::after_field();
		?>
		</script>
		<?php
	}
}
