<?php
class Barlog_Customizer_Control_Hr extends Barlog_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-barlog-hr">
		<?php
		echo '<hr/>';
		?>
		</script>
		<?php
	}
}
