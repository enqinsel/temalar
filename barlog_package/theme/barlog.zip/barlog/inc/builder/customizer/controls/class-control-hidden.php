<?php
class Barlog_Customizer_Control_Hidden extends Barlog_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-barlog-hidden">
		<?php
		self::before_field();
		?>
		<input type="hidden" class="barlog-input barlog-only" data-name="{{ field.name }}" value="{{ field.value }}">
		<?php
		self::after_field();
		?>
		</script>
		<?php
	}
}
