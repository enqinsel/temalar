<?php
class Barlog_Customizer_Control_Textarea extends Barlog_Customizer_Control_Base {
	static function field_template() {
		echo '<script type="text/html" id="tmpl-field-barlog-textarea">';
		self::before_field();
		?>
		<?php echo self::field_header(); ?>
		<div class="barlog-field-settings-inner">
			<textarea rows="10" class="barlog-input" data-name="{{ field.name }}">{{ field.value }}</textarea>
		</div>
		<?php
		self::after_field();
		echo '</script>';
	}
}
