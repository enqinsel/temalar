<?php
class Barlog_Customizer_Control_Icon extends Barlog_Customizer_Control_Base {
	static function field_template() {
		echo '<script type="text/html" id="tmpl-field-barlog-icon">';
		self::before_field();
		?>
		<#
		if ( ! _.isObject( field.value ) ) {
			field.value = { };
		}
		#>
		<?php echo self::field_header(); ?>
		<div class="barlog-field-settings-inner">
			<div class="barlog--icon-picker">
				<div class="barlog--icon-preview">
					<input type="hidden" class="barlog-input barlog--input-icon-type" data-name="{{ field.name }}-type" value="{{ field.value.type }}">
					<div class="barlog--icon-preview-icon barlog--pick-icon">
						<# if ( field.value.icon ) {  #>
							<i class="{{ field.value.icon }}"></i>
						<# }  #>
					</div>
				</div>
				<input type="text" readonly class="barlog-input barlog--pick-icon barlog--input-icon-name" placeholder="<?php esc_attr_e( 'Pick an icon', 'barlog' ); ?>" data-name="{{ field.name }}" value="{{ field.value.icon }}">
				<span class="barlog--icon-remove" title="<?php esc_attr_e( 'Remove', 'barlog' ); ?>">
					<span class="dashicons dashicons-no-alt"></span>
					<span class="screen-reader-text">
					<?php _e( 'Remove', 'barlog' ); ?></span>
				</span>
			</div>
		</div>
		<?php
		self::after_field();
		echo '</script>';
		?>
		<div id="barlog--sidebar-icons">
			<div class="barlog--sidebar-header">
				<a class="customize-controls-icon-close" href="#">
					<span class="screen-reader-text"><?php _e( 'Cancel', 'barlog' ); ?></span>
				</a>
				<div class="barlog--icon-type-inner">
					<select id="barlog--sidebar-icon-type">
						<option value="all"><?php _e( 'All Icon Types', 'barlog' ); ?></option>
					</select>
				</div>
			</div>
			<div class="barlog--sidebar-search">
				<input type="text" id="barlog--icon-search" placeholder="<?php esc_attr_e( 'Type icon name', 'barlog' ); ?>">
			</div>
			<div id="barlog--icon-browser"></div>
		</div>
		<?php
	}
}
