<?php
class Barlog_Customizer_Control_Shadow extends Barlog_Customizer_Control_Base {
	static function field_template() {
		echo '<script type="text/html" id="tmpl-field-barlog-shadow">';
		self::before_field();
		?>
		<#
			if ( ! _.isObject( field.value ) ) {
			field.value = { };
			}

			var uniqueID = field.name + ( new Date().getTime() );
		#>
			<?php echo self::field_header(); ?>
			<div class="barlog-field-settings-inner">

				<div class="barlog-input-color" data-default="{{ field.default }}">
					<input type="hidden" class="barlog-input barlog-input--color" data-name="{{ field.name }}-color" value="{{ field.value.color }}">
					<input type="text" class="barlog--color-panel" data-alpha="true" value="{{ field.value.color }}">
				</div>

				<div class="barlog--gr-inputs">
					<span>
						<input type="number" class="barlog-input barlog-input-css change-by-js"  data-name="{{ field.name }}-x" value="{{ field.value.x }}">
						<span class="barlog--small-label"><?php _e( 'X', 'barlog' ); ?></span>
					</span>
					<span>
						<input type="number" class="barlog-input barlog-input-css change-by-js"  data-name="{{ field.name }}-y" value="{{ field.value.y }}">
						<span class="barlog--small-label"><?php _e( 'Y', 'barlog' ); ?></span>
					</span>
					<span>
						<input type="number" class="barlog-input barlog-input-css change-by-js" data-name="{{ field.name }}-blur" value="{{ field.value.blur }}">
						<span class="barlog--small-label"><?php _e( 'Blur', 'barlog' ); ?></span>
					</span>
					<span>
						<input type="number" class="barlog-input barlog-input-css change-by-js" data-name="{{ field.name }}-spread" value="{{ field.value.spread }}">
						<span class="barlog--small-label"><?php _e( 'Spread', 'barlog' ); ?></span>
					</span>
					<span>
						<span class="input">
							<input type="checkbox" class="barlog-input barlog-input-css change-by-js" <# if ( field.value.inset == 1 ){ #> checked="checked" <# } #> data-name="{{ field.name }}-inset" value="{{ field.value.inset }}">
						</span>
						<span class="barlog--small-label"><?php _e( 'inset', 'barlog' ); ?></span>
					</span>
				</div>
			</div>
			<?php
			self::after_field();
			echo '</script>';
	}
}
