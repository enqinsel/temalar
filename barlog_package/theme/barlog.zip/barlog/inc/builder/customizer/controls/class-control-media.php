<?php
class Barlog_Customizer_Control_Media extends Barlog_Customizer_Control_Base {
	static function field_template() {
		echo '<script type="text/html" id="tmpl-field-barlog-media">';
		self::before_field();
		?>
		<#
		if ( ! _.isObject(field.value) ) {
			field.value = {};
		}
		var url = field.value.url;
		#>
		<?php echo self::field_header(); ?>
		<div class="barlog-field-settings-inner barlog-media-type-{{ field.type }}">
			<div class="barlog--media">
				<input type="hidden" class="attachment-id" value="{{ field.value.id }}" data-name="{{ field.name }}">
				<input type="hidden" class="attachment-url"  value="{{ field.value.url }}" data-name="{{ field.name }}-url">
				<input type="hidden" class="attachment-mime"  value="{{ field.value.mime }}" data-name="{{ field.name }}-mime">
				<div class="barlog-image-preview <# if ( url ) { #> barlog--has-file <# } #>" data-no-file-text="<?php esc_attr_e( 'No file selected', 'barlog' ); ?>">
					<#

					if ( url ) {
						if ( url.indexOf('http://') > -1 || url.indexOf('https://') ){

						} else {
							url = Barlog_Control_Args.home_url + url;
						}

						if ( ! field.value.mime || field.value.mime.indexOf('image/') > -1 ) {
							#>
							<img src="{{ url }}" alt="">
						<# } else if ( field.value.mime.indexOf('video/' ) > -1 ) { #>
							<video width="100%" height="" controls><source src="{{ url }}" type="{{ field.value.mime }}">Your browser does not support the video tag.</video>
						<# } else {
						var basename = url.replace(/^.*[\\\/]/, '');
						#>
							<a href="{{ url }}" class="attachment-file" target="_blank">{{ basename }}</a>
						<# }
					}
					#>
				</div>
				<button type="button" class="button barlog--add <# if ( url ) { #> barlog--hide <# } #>"><?php _e( 'Add', 'barlog' ); ?></button>
				<button type="button" class="button barlog--change <# if ( ! url ) { #> barlog--hide <# } #>"><?php _e( 'Change', 'barlog' ); ?></button>
				<button type="button" class="button barlog--remove <# if ( ! url ) { #> barlog--hide <# } #>"><?php _e( 'Remove', 'barlog' ); ?></button>
			</div>
		</div>

		<?php
		self::after_field();
		echo '</script>';
	}
}
