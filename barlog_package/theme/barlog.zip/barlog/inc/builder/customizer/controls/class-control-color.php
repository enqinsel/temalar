<?php
class Barlog_Customizer_Control_Color extends Barlog_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-barlog-color">
		<?php
		self::before_field();
		?>
		<?php echo self::field_header(); ?>
		<div class="barlog-field-settings-inner">
			<div class="barlog-input-color" data-default="{{ field.default }}">
				<input type="hidden" class="barlog-input barlog-input--color" data-name="{{ field.name }}" value="{{ field.value }}">
				<input type="text" class="barlog--color-panel" placeholder="{{ field.placeholder }}" data-alpha="true" value="{{ field.value }}">
			</div>
		</div>
		<?php
		self::after_field();
		?>
		</script>
		<?php
	}
}
