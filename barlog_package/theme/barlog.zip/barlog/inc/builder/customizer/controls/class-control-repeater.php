<?php

class Barlog_Customizer_Control_Repeater extends Barlog_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-barlog-repeater">
			<?php
			self::before_field();
			?>
			<?php echo self::field_header(); ?>
			<div class="barlog-field-settings-inner">
			</div>
			<?php
			self::after_field();
			?>
		</script>
		<script type="text/html" id="tmpl-customize-control-repeater-item">
			<div class="barlog--repeater-item">
				<div class="barlog--repeater-item-heading">
					<label class="barlog--repeater-visible" title="<?php esc_attr_e( 'Toggle item visible', 'barlog' ); ?>">
						<input type="checkbox" class="r-visible-input">
						<span class="r-visible-icon"></span>
						<span class="screen-reader-text"><?php _e( 'Show', 'barlog' ); ?></label>
					<span class="barlog--repeater-live-title"></span>
					<div class="barlog-nav-reorder">
						<span class="barlog--down" tabindex="-1">
							<span class="screen-reader-text"><?php _e( 'Move Down', 'barlog' ); ?></span></span>
						<span class="barlog--up" tabindex="0">
							<span class="screen-reader-text"><?php _e( 'Move Up', 'barlog' ); ?></span>
						</span>
					</div>
					<a href="#" class="barlog--repeater-item-toggle">
						<span class="screen-reader-text"><?php _e( 'Close', 'barlog' ); ?></span></a>
				</div>
				<div class="barlog--repeater-item-settings">
					<div class="barlog--repeater-item-inside">
						<div class="barlog--repeater-item-inner"></div>
						<# if ( data.addable ){ #>
						<a href="#" class="barlog--remove"><?php _e( 'Remove', 'barlog' ); ?></a>
						<# } #>
					</div>
				</div>
			</div>
		</script>
		<script type="text/html" id="tmpl-customize-control-repeater-inner">
			<div class="barlog--repeater-inner">
				<div class="barlog--settings-fields barlog--repeater-items"></div>
				<div class="barlog--repeater-actions">
				<a href="#" class="barlog--repeater-reorder"
				data-text="<?php esc_attr_e( 'Reorder', 'barlog' ); ?>"
				data-done="<?php _e( 'Done', 'barlog' ); ?>"><?php _e( 'Reorder', 'barlog' ); ?></a>
					<# if ( data.addable ){ #>
					<button type="button"
							class="button barlog--repeater-add-new"><?php _e( 'Add an item', 'barlog' ); ?></button>
					<# } #>
				</div>
			</div>
		</script>
		<?php
	}
}
