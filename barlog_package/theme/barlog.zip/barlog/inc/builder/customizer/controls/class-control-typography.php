<?php
class Barlog_Customizer_Control_Typography extends Barlog_Customizer_Control_Base {
	static function field_template() {
		echo '<script type="text/html" id="tmpl-field-barlog-typography">';
		self::before_field();
		?>
		<?php echo self::field_header(); ?>
		<div class="barlog-actions">
			<a href="#" class="action--reset" data-control="{{ field.name }}" title="<?php esc_attr_e( 'Reset to default', 'barlog' ); ?>"><span class="dashicons dashicons-image-rotate"></span></a>
			<a href="#" class="action--edit" data-control="{{ field.name }}" title="<?php esc_attr_e( 'Toggle edit panel', 'barlog' ); ?>"><span class="dashicons dashicons-editor-textcolor"></span></a>
		</div>
		<div class="barlog-field-settings-inner">
			<input type="hidden" class="barlog-typography-input barlog-only" data-name="{{ field.name }}" value="{{ JSON.stringify( field.value ) }}" data-default="{{ JSON.stringify( field.default ) }}">
		</div>
		<?php
		self::after_field();
		echo '</script>';
		?>
		<div id="barlog-typography-panel" class="barlog-typography-panel">
			<div class="barlog-typography-panel--inner">
				<input type="hidden" id="barlog--font-type">
				<div id="barlog-typography-panel--fields"></div>
			</div>
		</div>
		<?php
	}
}
