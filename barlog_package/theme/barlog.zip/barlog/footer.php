        </div>
        <?php
        /**
         * Hook before site content
         *
         */
        do_action( 'barlog/site-end' );


        ?>
      </div>
    </div>
  </div>
<?php wp_footer(); ?>

</body>
</html>