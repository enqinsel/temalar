<?php
/**
 * The template for displaying all single posts.
 *
 * @package barlog
 */
get_header();

do_action( 'barlog_before_main_content' );

get_template_part('templates/content/templates/content-single');

do_action( 'barlog_after_main_content' );

get_footer();